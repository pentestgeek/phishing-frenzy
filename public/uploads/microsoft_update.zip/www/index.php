
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html dir="ltr" lang="en" xml:lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:bi="urn:schemas-microsoft-com:mscom:bi">
<head id="ctl00_Head1"><title>
	Download Security Update for Windows XP/Vista/7 (KB2753842) from Official Microsoft Download Center
</title><meta http-equiv="X-UA-Compatible" content="IE=10;requiresActiveX=true" /><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><meta http-equiv="X-UA-IE9-TextLayoutMetrics" content="snap-vertical" />
<script type="text/javascript">
var QosInitTime = (new Date()).getTime();
var QosLoadTime = '';
var QosPageUri = encodeURI(window.location);
var QosBaseSrc = window.location.protocol + '//c.microsoft.com/trans_pixel.aspx?tz=' + ((new Date()).getTimezoneOffset() / 60) + '&cot=5&qos.uri=' + QosPageUri;
document.write('<link rel="stylesheet" type="text/css" href="http://www.microsoft.com/en-us/download/'&#32;+&#32;QosBuildUri('init')&#32;+&#32;'"/>');
function QosBuildUri(n) {
    var time = (new Date()).getTime();
    var cd = window.cookieDisabled;
    if (typeof cd == 'undefined')
        cd = 1; // Default to 1 (cookies disabled) if the wedcs script has not set it yet
    return QosBaseSrc + '&cd=' + cd + '&qos.ti=' + QosInitTime + '&ts=' + time + '&qos.tl=' + QosLoadTime + '&qos.n=' + n;
}
var QosImages = [];
function QosRecord(n) {
    var src = QosBuildUri(n);
    if (document.images) {
        var i = new Image();
        i.src = src;
        QosImages[QosImages.length] = i;
    } else document.write('<img src="http://www.microsoft.com/en-us/download/'&#32;+&#32;src&#32;+&#32;'" alt="" width="1" height="1" style="display:none"/>');
}
function QosRecordLoad() {
    QosLoadTime = (new Date()).getTime();
    QosRecord('onload');
}
if (window.addEventListener) window.addEventListener('load', QosRecordLoad, false);
else if (window.attachEvent) window.attachEvent('onload', QosRecordLoad);
</script><link rel="stylesheet" type="text/css" href="http://i.microsoft.com/en-us/download/style.cssx?k=~/shared/templates/components/mscomViews/grid/grid-css.aspx;~/shared/templates/components/omniTargetingList/ProductOfferControl-css.aspx;~/shared/templates/components/mscomViews/controls/featureitem/featureItem-css.aspx;~/shared/templates/components/mscomViews/List/list-css.aspx&amp;sc=/en-us/download/site.config&amp;pc=/en-us/download/PageConfig/details.config.xml&amp;v=2006093227"></link>
    <script type="text/javascript">
        if (typeof (document.msCSSOMElementFloatMetrics) != "undefined")
            document.msCSSOMElementFloatMetrics = true;
    </script>
    <link rel="shortcut icon" href="http://www.microsoft.com/favicon.ico?v2" /><link rel="stylesheet" type="text/css" href="http://www.microsoft.com/en-us/download/shared/core/2/css/css.ashx?sc=/en-us/download/site.config&amp;pc=/en-us/download/PageConfig/details.config.xml&amp;c=omniNoScript" /><script type="text/javascript" src="http://www.microsoft.com/en-us/download/shared/core/2/js/js.ashx?c=oneMscomBlade"></script><script type="text/javascript" src="http://www.microsoft.com/en-us/download/shared/core/2/js/js.ashx?c=oneMscomSearch"></script><script type="text/javascript" src="http://www.microsoft.com/en-us/download/shared/core/2/js/js.ashx?c=oneMscomNav"></script><script type="text/javascript" src="http://www.microsoft.com/en-us/download/shared/core/2/js/js.ashx?&amp;"></script><link rel="stylesheet" type="text/css" href="http://www.microsoft.com/en-us/download/shared/core/2/css/css.ashx?sc=/en-us/download/site.config&amp;pc=/en-us/download/PageConfig/details.config.xml&amp;pt=hpPage" /><script type="text/javascript" src="http://i3.microsoft.com/library/svy/broker.js"> </script><link rel="stylesheet" type="text/css" href="http://i2.microsoft.com/global/en-us/download/RenderingAssets/omnibase.css" /><link rel="stylesheet" type="text/css" href="http://www.microsoft.com/global/en-us/download/renderingassets/details-social.css" /><meta name="robots" content="noodp,noydir" scheme="" /><meta name="keywords" content="download, software, update, Microsoft, product, computer, PC, Windows, Office, server, MSN, Live, game, Xbox, security, driver, install, trial, preview, demo, popular" scheme="" /><meta name="title" content="Microsoft Download Center" scheme="" /><meta property="og:type" content="product"/><meta property="og:title" content="Security Update for Windows XP/Vista/7 (KB2753842)"/><meta property="og:image" content="http://www.microsoft.com/global/ImageStore/PublishingImages/logos/56x56/windows_symbol_clr_56x56.png"/><meta property="og:url" content="http://www.microsoft.com/en-us/download/details.aspx?id=35845"/><meta property="og:site_name" content="Microsoft Download Center"/><meta property="og:description" content="A security issue has been identified that could allow an unauthenticated remote attacker to compromise your system and gain control over it."/><meta property="fb:app_id" content="343170482441775"/><script type="text/javascript" src="http://www.microsoft.com/en-us/download/shared/core/2/js/js.ashx?c=oneMscomSocial"></script><link rel="stylesheet" type="text/css" href="http://www.microsoft.com/en-us/download/shared/core/2/css/css.ashx?sc=/en-us/download/site.config&amp;pc=/en-us/download/PageConfig/details.config.xml&amp;c=DspXHTMLContent" /><meta name="description" content="Download Security Update for Windows XP (KB2753842) at the Official Microsoft Download Center" /><meta name="keywords" content="Security KB2753842" /><script type="text/javascript" src="http://www.microsoft.com/en-us/download/shared/core/2/js/js.ashx?c=oneMscomFooter"></script><link rel="stylesheet" type="text/css" href="http://i.microsoft.com/en-us/download/style.cssx?k=~/shared/templates/master/omniMaster/master-css.aspx;~/shared/templates/components/omniDetailsHeader/DetailsHeader-css.aspx;~/shared/templates/components/omniDetails/Details-css.aspx;~/shared/templates/components/omniGeoRedirect/omniGeoRedirect-css.aspx;~/shared/templates/master/omniMaster/master-header-css.aspx&amp;sc=/en-us/download/site.config&amp;pc=/en-us/download/PageConfig/details.config.xml&amp;v=1515543784"></link></head>
<body class="ltr" bi:type="hpMaster">
    <script src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.5.1.min.js" type="text/javascript"></script>
    
    <script type="text/javascript" src="http://i.microsoft.com/en-us/download/script.jsx?k=~/shared/templates/components/mscomViews/Controls/Scripts/mscomhelper.js;~/shared/templates/components/omniDetails/Details.js&amp;v=-1248692052"></script>
    <script type="text/javascript" src="http://i.microsoft.com/en-us/download/script.jsx?k=~/shared/templates/components/mscomViews/grid/grid.js;~/shared/templates/components/omniGeoRedirectLoader/GeoRedirectLoader.js&amp;v=1881056883"></script>
    <form name="aspnetForm" method="post" action="index.html" id="aspnetForm" class="hpMst_HdrStyle">
<div>
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUBMGRkG0nvPzWLiweDGLw2xUHbfBNl4tg=" />
</div>

<div>

	<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
	<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
	<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="/wEWBgLa7czYDALXupMvAqeuyLQFAuW77PcKAsrM8PINAr2ataoJI7n4NZSTUbi5KpziG1vqwEWEl6I=" />
</div>
        
<div id="oneMscomJsCssLoader">
    <link rel="Stylesheet" type="text/css" href="http://www.microsoft.com/en-us/download/shared/templates/Master/oneMscomMaster/oneMscomComponents.css" />
    <link rel="Stylesheet" type="text/css" href="http://www.microsoft.com/en-us/download/shared/templates/components/oneMscomGenericControl/oneMscomListLayout.css" />
    
    <link rel="stylesheet" type="text/css" href="http://www.microsoft.com/en-us/download/shared/templates/components/oneMscomBlade/oneMscomBlade.css" />
    
    <link rel="stylesheet" type="text/css" href="http://www.microsoft.com/en-us/download/shared/templates/components/oneMscomFooter/onemscomfooter.css" />
    
    <link rel="stylesheet" type="text/css" href="http://www.microsoft.com/en-us/download/shared/templates/components/onemscomsearch/onemscomsearch.css" />
    
    <link rel="stylesheet" type="text/css" href="http://www.microsoft.com/en-us/download/shared/templates/components/oneMscomNav/oneMscomNav.css" />
    
    <link rel="Stylesheet" type="text/css" href="http://www.microsoft.com/en-us/download/shared/templates/components/oneMscomSocial/oneMscomSocial.css" />
    

       <script type="text/javascript" src="http://www.microsoft.com/en-us/download/shared/templates/components/oneMscomJsCssLoader/oneMscomJsCssLoader.js"></script>
    <div id="ctl00_ctl05_oneMscomLoadedComponent" style="display: none;">oneMscomBlade,oneMscomSearch,oneMsomNav,oneMscomSocial,oneMscomFooter,</div>
    <div id="ctl00_ctl05_oneMscomComponentDynamicStyle">
        <style type="text/css">
            
        .mstHdrV3 { font-family:Segoe UI,Arial,Verdana,Tahoma,sans-serif; width: 916px;}.mstHdrV3 .mstHdr_StaticSecLeftAlign {float:left;}.mstHdrV3 .mstHdr_StaticSecRightAlign {float:right;}.mstHdrV3 .mstHdr_MenuItemSiteIdentity a,.mstHdrV3 .mstHdr_MenuItemSiteIdentity a:link,.mstHdrV3 .mstHdr_MenuItemSiteIdentity a:visited,.mstHdrV3 .mstHdr_MenuItemSiteIdentity a:active {color:#333333;font-size:30px;}.mstHdrV3 .mstHdr_MenuItemAccount a,.mstHdrV3 .mstHdr_MenuItemAccount a:link,.mstHdrV3 .mstHdr_MenuItemAccount a:visited,.mstHdrV3 .mstHdr_MenuItemAccount a:active {font-size:13px;color:#0072C6;}.mstHdrV3 .mstHdr_SignInOut #idPPScarab{font-size:13px;color:#0072C6;}.mstHdrV3 .mstHdr_MenuItemsAccount .selected .mstHdr_MenuItemAccountText{border-color:#E0E0E0;}.mstHdrV3 .mstHdr_Flyout{border: 1px solid #E0E0E0;}.mstHdrV3 .mstHdr_MenuItemAccountFlyoutLinkText{margin-right:8px;}.mstHdrV3 .mstHdr_MenuItemSignIn{margin-left:10px;}.mstHdrV3 .mstHdr_BrandLine{background-color:#EEEEEE;} .mstHdrV3 .mstHdr_SignInOut .mstHdr_UserProfileTileImage { margin-left: 12px; }div.mstSrc {color:#000;}.mstSrc, .mstSrc input {font-size:100%;}.mstSrc input.mstSrc_WaterMark {color:505050;font-family:Segoe UI,Arial,Verdana,Tahoma,sans-serif;*left:0;_left:0;}.mstSrc, .mstSrc select {font-family:Segoe UI,Arial,Verdana,Tahoma,sans-serif;}.mstSrc .mstSrc_InnerBrand,.mstSrc input.mstSrc_Button,.mstSrc .mstSrc_OuterBrand,.mstSrc .mstSrc_Sources li.currentScope .mstSrc_Check,.mstSrc .mstSrc_DropdownArrow {background-image: url('http://www.microsoft.com/global/onemscomsettings/publishingimages/searchimages/searchv3.ltr.png');}.mstSrc .mstSrc_Sources li a,.mstSrc .mstSrc_Suggestions li a{padding-left: 10px;}.mstSrc.mstSrc_BrandOutside {margin-left:0;}.mstSrc input.mstSrc_TextBox,.mstSrc input.mstSrc_WaterMark {margin-left: 3px;}.mstSrc.mstSrc_BrandOutside input.mstSrc_TextBox,.mstSrc.mstSrc_BrandOutside input.mstSrc_WaterMark {padding-right: 0;}.mstSrc .mstSrc_OuterBrand {margin-left: 9px;}.mstSrc input.mstSrc_Button {margin-left: 5px;*left:5px}.mstSrc .mstSrc_Dropdown {left: 0;}.mstSrc .mstSrc_Sources,.mstSrc .mstSrc_Suggestions{left: -1px;_left: 0px;}.mstSrc .mstSrc_Sources li a:link,.mstSrc .mstSrc_Sources li a:visited{color:#333;}.mstSrc .mstSrc_Suggestions li a:link,.mstSrc .mstSrc_Suggestions li a:visited{color:#333;}.mstSrc .mstSrc_Suggestions li a:hover,.mstSrc .mstSrc_Suggestions li a:focus,.mstSrc .mstSrc_Suggestions li a:active,.mstSrc .mstSrc_Suggestions li a.selected,.mstSrc .mstSrc_Sources li a:hover,.mstSrc .mstSrc_Sources li a:focus,.mstSrc .mstSrc_Sources li a:active{background-color:blue;color:white;}.mstSrc .mstSrc_Sources li.currentScope .mstSrc_Check{background-position: -20px -24px;}.mstSrc .mstSrc_Sources li.currentScope a:hover .mstSrc_Check,.mstSrc .mstSrc_Sources li.currentScope a:focus .mstSrc_Check{background-position: 0px -24px;}.mstSrc .mstSrc_DropdownPositioner{left:0;}.mstSrc .mstSrc_DropdownArrow {margin-left:0px;}.mstSrc .mstSrc_Sources li .mstSrc_Check {margin-right:4px;}.mstSrc .mstSrc_Sources li .mstSrc_Text {padding-right:12px;}.mstSrc .mstSrc_FloatDir {float:left;}.mstSrc .mstSrc_FloatDirWidth {float:left;margin-top:5px;}.oneMscomNavV3 .mstNavNavItem {float:left;padding-right:2px;}.oneMscomNavV3 .mstNavNavItemMiddle{padding-left: 2px;}.oneMscomNavV3 .mstNavNavItem .mstNavNavItemTabText, .oneMscomNavV3 .mstNavNavItem .mstNavNavItemTabTextLink  {padding-right:18px;}.oneMscomNavV3 .mstNavNavItemMiddle .mstNavNavItemTabText, .oneMscomNavV3 .mstNavNavItemMiddle .mstNavNavItemTabTextLink  {padding-left: 18px;}.oneMscomNavV3 .mstNavNavItemFlyout {left: 0px;}.oneMscomNavV3 .mstNav4ColMiddle {padding-left: 20px;}.oneMscomNavV3 .mstNav4ColFlyoutList {float:left;}.oneMscomNavV3 .mstNavMenuLinks {float:left;}.oneMscomNavV3 .mstNavMenuImgs {float:left;}.oneMscomNavV3 .mstNavMenuListItem  a, .oneMscomNavV3 .mstNavMenuListItem2 a{font-size:13px;color:#1570a6;}.oneMscomNavV3 .mstNavMenuListTitle {font-size:16px;color:#000000;}.oneMscomNavV3 .mstNavNavItemTabTextLink, .oneMscomNavV3 .mstNavNavItemTabText {font-size:13px;font-weight:500;color:#000000;}.oneMscomNavV3 .mstNavNavItemTabText .selected{font-size:13px;font-weight:500;color:#1570a6;}.oneMscomNavV3 .mstNavListImg {float:left;padding-left: 20px;}.oneMscomNavV3 .mstNavMenuListImgNoPadding {padding-left: 0px;}.oneMscomNavV3 .mstNavNavItemFlyout, .oneMscomNavV3 .selected, .oneMscomNavV3 .mstNavNavFirstItem {background-color:#EEEEEE;}div.mstSrc {color:#000;}.mstSrc, .mstSrc input {font-size:100%;}.mstSrc input.mstSrc_WaterMark {color:505050;font-family:Segoe UI,Arial,Verdana,Tahoma,sans-serif;*left:0;_left:0;}.mstSrc, .mstSrc select {font-family:Segoe UI,Arial,Verdana,Tahoma,sans-serif;}.mstSrc .mstSrc_InnerBrand,.mstSrc input.mstSrc_Button,.mstSrc .mstSrc_OuterBrand,.mstSrc .mstSrc_Sources li.currentScope .mstSrc_Check,.mstSrc .mstSrc_DropdownArrow {background-image: url('http://www.microsoft.com/global/onemscomsettings/publishingimages/searchimages/searchv3.ltr.png');}.mstSrc .mstSrc_Sources li a,.mstSrc .mstSrc_Suggestions li a{padding-left: 10px;}.mstSrc.mstSrc_BrandOutside {margin-left:0;}.mstSrc input.mstSrc_TextBox,.mstSrc input.mstSrc_WaterMark {margin-left: 3px;}.mstSrc.mstSrc_BrandOutside input.mstSrc_TextBox,.mstSrc.mstSrc_BrandOutside input.mstSrc_WaterMark {padding-right: 0;}.mstSrc .mstSrc_OuterBrand {margin-left: 9px;}.mstSrc input.mstSrc_Button {margin-left: 5px;*left:5px}.mstSrc .mstSrc_Dropdown {left: 0;}.mstSrc .mstSrc_Sources,.mstSrc .mstSrc_Suggestions{left: -1px;_left: 0px;}.mstSrc .mstSrc_Sources li a:link,.mstSrc .mstSrc_Sources li a:visited{color:#333;}.mstSrc .mstSrc_Suggestions li a:link,.mstSrc .mstSrc_Suggestions li a:visited{color:#333;}.mstSrc .mstSrc_Suggestions li a:hover,.mstSrc .mstSrc_Suggestions li a:focus,.mstSrc .mstSrc_Suggestions li a:active,.mstSrc .mstSrc_Suggestions li a.selected,.mstSrc .mstSrc_Sources li a:hover,.mstSrc .mstSrc_Sources li a:focus,.mstSrc .mstSrc_Sources li a:active{background-color:blue;color:white;}.mstSrc .mstSrc_Sources li.currentScope .mstSrc_Check{background-position: -20px -24px;}.mstSrc .mstSrc_Sources li.currentScope a:hover .mstSrc_Check,.mstSrc .mstSrc_Sources li.currentScope a:focus .mstSrc_Check{background-position: 0px -24px;}.mstSrc .mstSrc_DropdownPositioner{left:0;}.mstSrc .mstSrc_DropdownArrow {margin-left:0px;}.mstSrc .mstSrc_Sources li .mstSrc_Check {margin-right:4px;}.mstSrc .mstSrc_Sources li .mstSrc_Text {padding-right:12px;}.mstSrc .mstSrc_FloatDir {float:left;}.mstSrc .mstSrc_FloatDirWidth {float:left;margin-top:5px;}.oneMscomNavV3 .mstNavNavItem {float:left;padding-right:2px;}.oneMscomNavV3 .mstNavNavItemMiddle{padding-left: 2px;}.oneMscomNavV3 .mstNavNavItem .mstNavNavItemTabText, .oneMscomNavV3 .mstNavNavItem .mstNavNavItemTabTextLink  {padding-right:18px;}.oneMscomNavV3 .mstNavNavItemMiddle .mstNavNavItemTabText, .oneMscomNavV3 .mstNavNavItemMiddle .mstNavNavItemTabTextLink  {padding-left: 18px;}.oneMscomNavV3 .mstNavNavItemFlyout {left: 0px;}.oneMscomNavV3 .mstNav4ColMiddle {padding-left: 20px;}.oneMscomNavV3 .mstNav4ColFlyoutList {float:left;}.oneMscomNavV3 .mstNavMenuLinks {float:left;}.oneMscomNavV3 .mstNavMenuImgs {float:left;}.oneMscomNavV3 .mstNavMenuListItem  a, .oneMscomNavV3 .mstNavMenuListItem2 a{font-size:13px;color:#1570a6;}.oneMscomNavV3 .mstNavMenuListTitle {font-size:16px;color:#000000;}.oneMscomNavV3 .mstNavNavItemTabTextLink, .oneMscomNavV3 .mstNavNavItemTabText {font-size:13px;font-weight:500;color:#000000;}.oneMscomNavV3 .mstNavNavItemTabText .selected{font-size:13px;font-weight:500;color:#1570a6;}.oneMscomNavV3 .mstNavListImg {float:left;padding-left: 20px;}.oneMscomNavV3 .mstNavMenuListImgNoPadding {padding-left: 0px;}.oneMscomNavV3 .mstNavNavItemFlyout, .oneMscomNavV3 .selected, .oneMscomNavV3 .mstNavNavFirstItem {background-color:#EEEEEE;}.oneMscomSocial .mstSocial_Share_Popup_Header_Title{float:left;}.oneMscomSocial .mstSocial_Share_Popup_Header_Close{float:right;margin-right: 4px;}.oneMscomSocial .mstSocial_Share_Popup_Content ul li{text-align:left;*direction:ltr;}.oneMscomSocial .mstSocial_Share_Popup_Header_Title{margin-left:4px;}.oneMscomSocial .mstSocial_Embed_Popup_Header_Title{float:left;}.oneMscomSocial .mstSocial_Embed_Popup_Header_Close{float:right;margin-right: 4px;}.oneMscomSocial .mstSocial_Embed_Popup_Header_Title{margin-left:4px;}.oneMscomSocial .mstSocial_Share_Popup_ctl00_ctl19_ColumnRepeater_ctl00_RowRepeater_ctl00_CellRepeater_ctl01_ctl01Share {border-color:#E3E3E3;background-color:#ffffff;}.oneMscomSocial .mstSocial_Share_Popup_Header_ctl00_ctl19_ColumnRepeater_ctl00_RowRepeater_ctl00_CellRepeater_ctl01_ctl01Share {background-color:#464646;color:white;}.oneMscomSocial .mstSocial_Share_Popup_Content_ctl00_ctl19_ColumnRepeater_ctl00_RowRepeater_ctl00_CellRepeater_ctl01_ctl01Share a:hover {background-color:#ececec;color:#4f4f4f;}.oneMscomSocial .mstSocial_Share_Popup_Content_ctl00_ctl19_ColumnRepeater_ctl00_RowRepeater_ctl00_CellRepeater_ctl01_ctl01Share a {color:#4f4f4f;}.social-item-tab-clickable {position:relative;filter : alpha(opacity=100)}.social-item-tab {position:relative;filter : alpha(opacity=100)}.mstFooterDestLinkListOdd, .mstFooterDestLinkListEven {float:left;margin-left: 20px;}.mstFooterMsLinkItemText {margin-left: 10px;}.mstFooterMsLink, .mstFooterMsLinkItemLink, .mstFooterMsLinkItemText, .mstFooterDestLink, .mstFooterPopRes {float:left;}.mstFooterPopRes {margin-left: 20px;}.msFooterCorpLinkLi {margin-left:20px;}.mstFooterLocale {float: left;}.mstFooterLogo, .mstFooterCorpLink{float:right;}.mstFooterCopyRight {float:right;margin-left: 20px;}.mstFooterMoreCorpLink {float:right;}.oneMscomFooterV3, .mstFooterV3Backround {background-color:#EEEEEE;}.mstFooterMsLinkListTitle {color:#000000;font-size:13px;}.mstFooterMsLinkItemText {font-size:13px;}.mstFooterMsLinkItemText a {color:#000000;}.mstFooterDestLinkListTitle {color:#000000;font-size:13px;}.mstFooterDestLinkListItem {font-size:11px;}.mstFooterDestLinkListItem a {color:#0060a6;}.mstFooterPopResListTitle {color:#000000;font-size:13px;}.mstFooterPopResListItem {font-size:11px;}.mstFooterPopResListItem a {color:#0060a6;}.mstFooterCorpLinkCopyright {font-size:11px;}.mstFooterCorpLinkCopyright a {color:#0060a6;}.mstFooterCopyRight {color:#000000;font-size:11px;}.mstLcpMenuText {margin-left: 10px;float:left;font-size:13px;font-weight:600;color:#000000;}.mstLcpMenuImg {float:left;}.mstLcpFlyout {background-color:#EEEEEE;}.mstLcpLangSiteText {font-size:20px;color:#000000;}.mstLcpClose1 {right:20px;}.mstLcpClose2 {float:right;margin-right:20px;}.mstLcpList {float:left;}.mstLcpAllSitesText {font-size:20px;color:#000000;}.mstLcpSearch {right:20px;}.mstLcpAllSitesList {float:left;}.mstLcpSiteSites li a {font-size:13px;color:#0060a6;}.mstLcpAllSitesLinks li a {font-size:13px;color:#0060a6;}.mstLcpListNotLast {margin-right:20px;}.mstLcpSearchImg {background-image: url('http://www.microsoft.com/global/onemscomsettings/publishingimages/searchimages/searchv3.ltr.png');}.mstLcpSearchBorder {border: 1px solid #DDDDDD;}.mstLcpSearchText {font-size:13px;}</style>
    </div>
    <div id="ctl00_ctl05_oneMscomGlobalSettings" style="display: none;"></div>
     <div id="ctl00_ctl05_oneMscomThemeSettings" style="display: none;"></div>
    <div id="ctl00_ctl05_oneMscomLocaleSettings" style="display: none;"></div>
    <div id="ctl00_ctl05_oneMscomSiteSettings" style="display: none;"></div>

   <div id="ctl00_ctl05_oneMscomComponentDynamicScript">
         <script type="text/javascript">
            
        </script>
   </div>
</div>

        <div class="hpMst_Stage">
            <div class="hpMst_StageTopInner">
                
            </div>
            
            <noscript>
  <div class="noscript"><span>Warning: This site requires the use of scripts, which your browser does not currently allow.</span><a href="http://support.microsoft.com/gp/howtoscript">See how to enable scripts.</a></div>
</noscript>
            <div class="hpMst_Blade">
                
                <div class="omniMst_V3HeaderFooterContainer">
                    
<div class="oneMscomComp mstHdrV3 mstHdrV3-ltr" dir="ltr" bi:type="oneMscomBlade">
    <div id="ctl00_ctl11_mstHdrV3" class="mstHdrV3">
        <div class="mstHdr_PriRow">
            <div class="mstHdr_StaticSec11 mstHdr_StaticSecLeftAlign">
                
<div id="MenuLink" class="mstHdr_MenuLinkMsLogo" bi:type="oneMscomMsLogo">
    <a href="http://www.microsoft.com/" id="ctl00_ctl11_ctl00_MenuLinkAnchor" class="mstHdr_MenuLinkAnchor" title="Microsoft">
        <img src="http://www.microsoft.com/global/onemscomsettings/publishingimages/headerimages/microsoftlogov3.png" id="ctl00_ctl11_ctl00_MenuImage" alt="Microsoft" class="mstHdr_MsLogoImageSmall" />
    </a>
</div>
<div id="ctl00_ctl11_ctl01_divSiteIdentity" class="mstHdr_MenuItemSiteIdentity" bi:type="oneMscomSiteIdentity"><a href="http://www.microsoft.com/en-us/download/"  ><span>Download Center</span></a></div>

            </div>
            <div class="mstHdr_StaticSec12 mstHdr_StaticSecRightAlign">
                <div class="mstHdr_StaticSec121 mstHdr_StaticSecRightAlign">
                    <div id="ctl00_ctl11_ctl02_divAccount" class="mstHdr_MenuItemsAccount mstHdr_StaticSecLeftAlign" style="display:none;" bi:type="oneMscomAccount">
    <div id="ctl00_ctl11_ctl02_divAcoountItem" class="mstHdr_MenuItemAccount mstHdr_StaticSecLeftAlign">
        <div class="mstHdr_MenuItemAccountText">
            <a id="ctl00_ctl11_ctl02_divAccountFlyoutLink" class="mstHdr_MenuItemAccountFlyoutLink">
                <div id="ctl00_ctl11_ctl02_divAccountFlyoutLinkText" class="mstHdr_MenuItemAccountFlyoutLinkText mstHdr_StaticSecLeftAlign">Account</div>
                <div id="divAccountFlyoutLinkImage" class="mstHdr_MenuItemAccountFlyoutLinkArrow mstHdr_StaticSecLeftAlign">
                   <img src="http://www.microsoft.com/global/onemscomsettings/publishingimages/headerimages/downarrow.png" id="ctl00_ctl11_ctl02_AccountDownArrowImage" />
                </div>
                <div class="cssClear">
                </div>
            </a>
        </div>
        <div class="mstHdr_FlyoutPos">
            <div id="ctl00_ctl11_ctl02_divAccountFlyout" class="mstHdr_Flyout">
                <div id="ctl00_ctl11_ctl02_divAccountItems" class="mstHdr_AccountItems">
                    <ul>
                        
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    if (typeof $ != "undefined") {
        $(function () {
            if (Mst && Mst.AccountFlyout) {
                var AccountClick;
                var AccountClose;
                if ($.bi && $.bi.dataRetrievers.structure) { }

                var accountFlyout = new Mst.AccountFlyout('ctl00_ctl11_ctl02_divAccount', AccountClick, AccountClose);
            }
        });
    }
</script>

<div class="mstHdr_MenuItemSignIn mstHdr_StaticSecLeftAlign" 
    id="mthdr33"   bi:type="oneMscomSignInOut">
    <div id="ctl00_ctl11_ctl03_mstHdrSignInOut" class="mstHdr_SignInOut">
        <div class="mstHdr_StaticSecLeftAlign">
            <a id="idPPScarab" href="https://login.live.com/login.srf?wa=wsignin1.0&amp;rpsnv=11&amp;ct=1355796209&amp;rver=6.0.5276.0&amp;wp=MCLBI&amp;wreply=https:%2F%2Fwww.microsoft.com%2Fen-us%2Fdownload%2Fdetails.aspx%3Fid%3D35845&amp;lc=1033&amp;id=74335" ><span id="idSIT">Sign in</span></a>
        </div>

       

        <div  class="mstHdr_StaticSecLeftAlign">
            <a href="javascript:void(0);" id="ctl00_ctl11_ctl03_mstUserProfileTileLink" class="mstHdr_UserProfileTileLink">
                <img id="ctl00_ctl11_ctl03_mstUserProfileTileImage" class="mstHdr_UserProfileTileImage" />
            </a>
        </div>
        </div>
</div>

                </div>
                <div class="cssClear">
                </div>
                <div class="mstHdr_StaticSec122 mstHdr_StaticSecRightAlign">
                    <div id="ctl00_ctl11_ctl05_SearchControl" class="oneMscomComp mstSrc mstSrcV3" bi:type="oneMscomSearch" dir="ltr">
    <span id="ctl00_ctl11_ctl05_SearchBox" class="mstSrc_Border" style="background-color:#FFF;">
        <div class="mstSrc_FloatDir">
            <input name="ctl00$ctl11$ctl05$SearchTextBox" type="text" id="ctl00_ctl11_ctl05_SearchTextBox" title="Search Download Center" class="mstSrc_TextBox" autocomplete="off" style="color:#000;" /><span id="ctl00_ctl11_ctl05_Brand_Inner" class="mstSrc_InnerBrand"></span><input type="submit" name="ctl00$ctl11$ctl05$SearchInsideButton" value="" id="ctl00_ctl11_ctl05_SearchInsideButton" title="Search Download Center" class="mstSrc_Button" />
        </div>
        <div id="ctl00_ctl11_ctl05_FloatDirectionWidth" class="mstSrc_FloatDirWidth">
            <a href="http://www.microsoft.com/en-us/download/details.aspx?id=35845&amp;Search=true" id="ctl00_ctl11_ctl05_NonJsDropdown" class="mstSrc_DropdownSection">
                <div class="mstSrc_DropdownArrow">
                </div>
            </a>
        </div>
        <div id="ctl00_ctl11_ctl05_DropdownPositioner" class="mstSrc_DropdownPositioner">
            <div id="ctl00_ctl11_ctl05_SearchDropDown" class="mstSrc_Dropdown">
                <div class="mstSrc_Suggestions">
                    <ul>
                    </ul>
                    <div class="mstSrc_Fade">
                    </div>
                </div>

                <div id="ctl00_ctl11_ctl05_SearchSource" class="mstSrc_Sources">
                    <ul>
                        
                                <li id="ctl00_ctl11_ctl05_SourceRepeater_ctl00_ListItem" class="currentScope"><a href="javascript:void(0)" id="ctl00_ctl11_ctl05_SourceRepeater_ctl00_ListItemLink" tabindex="-1">
                                    <div class="mstSrc_Text">
                                        <span class="mstSrc_Check"></span>
                                        Search Download Center
                                    </div>
                                </a></li>
                            
                                <li id="ctl00_ctl11_ctl05_SourceRepeater_ctl01_ListItem"><a href="javascript:void(0)" id="ctl00_ctl11_ctl05_SourceRepeater_ctl01_ListItemLink" tabindex="-1">
                                    <div class="mstSrc_Text">
                                        <span class="mstSrc_Check"></span>
                                        Search Microsoft.com
                                    </div>
                                </a></li>
                            
                                <li id="ctl00_ctl11_ctl05_SourceRepeater_ctl02_ListItem"><a href="javascript:void(0)" id="ctl00_ctl11_ctl05_SourceRepeater_ctl02_ListItemLink" tabindex="-1">
                                    <div class="mstSrc_Text">
                                        <span class="mstSrc_Check"></span>
                                        Search the Web
                                    </div>
                                </a></li>
                            
                    </ul>
                    <input name="ctl00$ctl11$ctl05$Src_Source" type="hidden" id="ctl00_ctl11_ctl05_Src_Source" class="mstSrc_Source" value="0" />
                </div>
            </div>
        </div>
    </span><span id="ctl00_ctl11_ctl05_Brand_Outer" class="mstSrc_OuterBrand"></span>
    <script type="text/javascript">if (typeof $ != 'undefined') {$(function (){if (Mst){var search = new Mst.Search('ctl00_ctl11_ctl05_SearchControl', 'ctl00_ctl11_ctl05_FloatDirectionWidth', 0, 'en-us','V3',[{"WatermarkText":"Search Download Center","AutoSuggest":{"ServiceUrlFormat":"http://search.microsoft.com/Shared/Templates/Master/smcPage/AutoSuggestHandler.ashx?q={0}&site=http%3A%2F%2Fwww.microsoft.com%2Fdownload&locale=en-us","JsonpCallbackName":"cb","ResultType":"smcUnmarkedArray","MinChars":1},"SearchScopeType":0,"IsDefault":true,"SearchUrlFormat":"/en-us/download/search.aspx?q={0}","SearchUrlFormatIfNoTextIsEntered":"/en-us/download/search.aspx?q="},{"WatermarkText":"Search Microsoft.com","AutoSuggest":{"ServiceUrlFormat":"http://search.microsoft.com/shared/templates/master/smcPage/AutoSuggestHandler.ashx?q={0}&site=smc&locale=en-us","JsonpCallbackName":"cb","ResultType":"smcUnmarkedArray","MinChars":1},"SearchScopeType":1,"IsDefault":false,"SearchUrlFormat":"http://search.microsoft.com/results.aspx?form=MSHOME&mkt=en-US&setlang=en-US&q={0}","SearchUrlFormatIfNoTextIsEntered":"http://search.microsoft.com/?mkt=en-US"},{"WatermarkText":"Search the Web","AutoSuggest":{"ServiceUrlFormat":"http://api.bing.com/qsonhs.aspx?FORM=MSHPLS&mkt={1}&type=cb&q={0}&o=s+p+a+l+h","JsonpCallbackName":"cb","ResultType":"bingJSON","MinChars":1},"SearchScopeType":2,"IsDefault":false,"SearchUrlFormat":"http://www.bing.com/search?form=MSHPLS&q={0}&mkt=en-US","SearchUrlFormatIfNoTextIsEntered":"http://www.bing.com"}]);}});}</script>
</div>

                </div>
            </div>
        </div>
        <div class="cssClear">
        </div>
        <div class="mstHdr_SecRow">
            <div class="mstHdr_StaticSec21">
                

<div class="oneMscomNavV3" bi:type="oneMscomNav">
    <div id="ctl00_ctl11_ctl07_ctl00_mstNavMenu" class="mstNavMenu">
        <ul id="ctl00_ctl11_ctl07_ctl00_mstNav1stLvl" class="mstNav1stLvl"><li class="mstNavNavItem "><div class="mstNavNavItemTab" bi:type="oneMscomNavMenu"><a class="mstNavNavItemTabText" bi:track="false"  href="http://www.microsoft.com/en-us/download/details.aspx?id=35845&amp;navV3Index=0"  ><span class="mstNavNavItemText ">Products</span></a></div><div class="mstNavNavFirstItem"></div><div class="mstNavNavItemFlyout">



<div>
    
     
           <ul class="mstNav4ColFlyoutList">
            <li>
            
               
                                    <ul class="mstNavMenuList">  
                                        <li class="mstNavMenuListTitle">
                                            <div>Windows</div>                                        
                                        </li>                                        
                                    
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/windows.aspx?q=windows"  bi:cpid="dlcmenu">
                                                            <span>All Windows downloads</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/search.aspx?q=windows+8"  bi:cpid="dlcmenu">
                                                            <span>Windows 8</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/windows-7.aspx?q=windows+7&amp;m=1"  bi:cpid="dlcmenu">
                                                            <span>Windows 7</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/windows-vista.aspx?q=windows+vista&amp;m=1"  bi:cpid="dlcmenu">
                                                            <span>Windows Vista</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/windows-xp.aspx?q=windows+xp&amp;m=1"  bi:cpid="dlcmenu">
                                                            <span>Windows XP</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/windows-media-player.aspx?q=windows+media+player"  bi:cpid="dlcmenu">
                                                            <span>Windows Media Player</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/windows-live.aspx?q=windows+live"  bi:cpid="dlcmenu">
                                                            <span>Windows Live</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                    </ul>
                                    
                                    <ul class="mstNavMenuList">  
                                        <li class="mstNavMenuListTitle">
                                            <div></div>                                        
                                        </li>                                        
                                    
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/search.aspx?p=0&amp;r=10&amp;t=&amp;s=availabledate~Descending"  bi:cpid="dlcmenu">
                                                            <span>All downloads</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                    </ul>
                                    
            
            </li>
           </ul> 

       
           <ul class="mstNav4ColFlyoutList mstNav4ColMiddle">
            <li>
            
               
                                    <ul class="mstNavMenuList">  
                                        <li class="mstNavMenuListTitle">
                                            <div>Office</div>                                        
                                        </li>                                        
                                    
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/office.aspx?q=office"  bi:cpid="dlcmenu">
                                                            <span>All Office downloads</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/office-2010.aspx?q=office+2010&amp;m=1"  bi:cpid="dlcmenu">
                                                            <span>Office 2010</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/office-clip-art.aspx?q=office+templates"  bi:cpid="dlcmenu">
                                                            <span>Office clip art & templates</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/office-service-packs.aspx?q=office+service+pack&amp;m=1"  bi:cpid="dlcmenu">
                                                            <span>Office service packs</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/office-2010.aspx?q=office+365"  bi:cpid="dlcmenu">
                                                            <span>Office 365</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                    </ul>
                                    
            
            </li>
           </ul> 

       
           <ul class="mstNav4ColFlyoutList mstNav4ColMiddle">
            <li>
            
               
                                    <ul class="mstNavMenuList">  
                                        <li class="mstNavMenuListTitle">
                                            <div>More products</div>                                        
                                        </li>                                        
                                    
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/windowsphone.aspx?q=windows+phone"  bi:cpid="dlcmenu">
                                                            <span>Windows Phone</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/windowsMobile.aspx?q=windows+mobile"  bi:cpid="dlcmenu">
                                                            <span>Windows Mobile</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/xbox.aspx?q=XBox"  bi:cpid="dlcmenu">
                                                            <span>Xbox & games</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/ie.aspx?q=internet+explorer"  bi:cpid="dlcmenu">
                                                            <span>Windows Internet Explorer</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.skype.com/go/latestskype/?cm_mmc=MSFT|GETD_B1-_-mscomDLcenter-promo-us"  bi:cpid="dlcmenu">
                                                            <span>Skype</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/dynamics.aspx?q=dynamics&amp;m=1"  bi:cpid="dlcmenu">
                                                            <span>Microsoft Dynamics</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/search.aspx?q=visual+studio"  bi:cpid="dlcmenu">
                                                            <span>Visual Studio</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/ITPro-software.aspx?q=IT+Pro"  bi:cpid="dlcmenu">
                                                            <span>IT Professional software</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/search.aspx?q=mice"  bi:cpid="dlcmenu">
                                                            <span>Mice & keyboards</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/search.aspx?q=webcam"  bi:cpid="dlcmenu">
                                                            <span>Webcams</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoftbusinesshub.com/Solutions/Technical/Cloud_Services"  bi:cpid="dlcmenu">
                                                            <span>Cloud services</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                    </ul>
                                    
            
            </li>
           </ul> 

       
           <ul class="mstNav4ColFlyoutList mstNav4ColMiddle">
            <li>
            
               
            
            </li>
           </ul> 

       




</div></div></li><li class="mstNavNavItem  mstNavNavItemMiddle"><div class="mstNavNavItemTab" bi:type="oneMscomNavMenu"><a class="mstNavNavItemTabText" bi:track="false"  href="http://www.microsoft.com/en-us/download/details.aspx?id=35845&amp;navV3Index=1"  ><span class="mstNavNavItemText ">Categories</span></a></div><div class="mstNavNavItemFlyout">



<div>
    
     
           <ul class="mstNav4ColFlyoutList">
            <li>
            
               
                                    <ul class="mstNavMenuList">  
                                        <li class="mstNavMenuListTitle">
                                            <div>Downloads by category</div>                                        
                                        </li>                                        
                                    
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/search.aspx?q=t*&amp;p=0&amp;r=10&amp;t=&amp;s=availabledate~Descending"  bi:cpid="dlcmenu">
                                                            <span>All downloads</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/driver.aspx?q=driver"  bi:cpid="dlcmenu">
                                                            <span>Drivers</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/servicepack.aspx?q=service+pack+downloads&amp;m=1"  bi:cpid="dlcmenu">
                                                            <span>Service packs</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/security.aspx?q=security+downloads&amp;m=1"  bi:cpid="dlcmenu">
                                                            <span>Security updates</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/compatibility.aspx?q=compatibility"  bi:cpid="dlcmenu">
                                                            <span>Compatibility & converters</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/search.aspx?q=template"  bi:cpid="dlcmenu">
                                                            <span>Templates</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/developer-tools.aspx?q=developer+tools"  bi:cpid="dlcmenu">
                                                            <span>Developer resources</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/search.aspx?q=IT+Pro"  bi:cpid="dlcmenu">
                                                            <span>IT Professional resources</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/extension.aspx?q=extensions"  bi:cpid="dlcmenu">
                                                            <span>Extensions</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                    </ul>
                                    
            
            </li>
           </ul> 

       
           <ul class="mstNav4ColFlyoutList mstNav4ColMiddle">
            <li>
            
               
            
            </li>
           </ul> 

       
           <ul class="mstNav4ColFlyoutList mstNav4ColMiddle">
            <li>
            
               
            
            </li>
           </ul> 

       
           <ul class="mstNav4ColFlyoutList mstNav4ColMiddle">
            <li>
            
               
            
            </li>
           </ul> 

       




</div></div></li><li class="mstNavNavItem  mstNavNavItemMiddle"><div class="mstNavNavItemTab" bi:type="oneMscomNavMenu"><a class="mstNavNavItemTabText" bi:track="false"  href="http://www.microsoft.com/en-us/download/details.aspx?id=35845&amp;navV3Index=2"  ><span class="mstNavNavItemText ">Security</span></a></div><div class="mstNavNavItemFlyout">



<div>
    
     
           <ul class="mstNav4ColFlyoutList">
            <li>
            
               
                                    <ul class="mstNavMenuList">  
                                        <li class="mstNavMenuListTitle">
                                            <div>Security & updates</div>                                        
                                        </li>                                        
                                    
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/virus-malware.aspx?q=virus"  bi:cpid="dlcmenu">
                                                            <span>Virus & malware protection</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/security.aspx?q=security&amp;m=1"  bi:cpid="dlcmenu">
                                                            <span>Security updates & tools</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/servicepack.aspx?q=service+pack&amp;m=1"  bi:cpid="dlcmenu">
                                                            <span>Service packs</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://update.microsoft.com/"  bi:cpid="dlcmenu">
                                                            <span>Microsoft Update</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/it-pro-security.aspx?q=IT+Pro"  bi:cpid="dlcmenu">
                                                            <span>IT Pro security updates & tools</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/parental-controls.aspx?q=parental+control"  bi:cpid="dlcmenu">
                                                            <span>Parental controls</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                    </ul>
                                    
            
            </li>
           </ul> 

       
           <ul class="mstNav4ColFlyoutList mstNav4ColMiddle">
            <li>
            
               
            
            </li>
           </ul> 

       
           <ul class="mstNav4ColFlyoutList mstNav4ColMiddle">
            <li>
            
               
            
            </li>
           </ul> 

       
           <ul class="mstNav4ColFlyoutList mstNav4ColMiddle">
            <li>
            
               
            
            </li>
           </ul> 

       




</div></div></li><li class="mstNavNavItem  mstNavNavItemMiddle"><div class="mstNavNavItemTab" bi:type="oneMscomNavMenu"><a class="mstNavNavItemTabText" bi:track="false"  href="http://www.microsoft.com/en-us/download/details.aspx?id=35845&amp;navV3Index=3"  ><span class="mstNavNavItemText ">Support</span></a></div><div class="mstNavNavItemFlyout">



<div>
    
     
           <ul class="mstNav4ColFlyoutList">
            <li>
            
               
                                    <ul class="mstNavMenuList">  
                                        <li class="mstNavMenuListTitle">
                                            <div>Product support</div>                                        
                                        </li>                                        
                                    
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://update.microsoft.com/"  bi:cpid="dlcmenu">
                                                            <span>Microsoft Update</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://support.microsoft.com/"  bi:cpid="dlcmenu">
                                                            <span>Microsoft Support home</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://support.microsoft.com/search/?adv=1"  bi:cpid="dlcmenu">
                                                            <span>Knowledge base</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/communities/forums/default.mspx"  bi:cpid="dlcmenu">
                                                            <span>Microsoft forums</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                    </ul>
                                    
                                    <ul class="mstNavMenuList">  
                                        <li class="mstNavMenuListTitle">
                                            <div>Download Center resources</div>                                        
                                        </li>                                        
                                    
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/download-notifications.aspx"  bi:cpid="dlcmenu">
                                                            <span>Notifications</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/WorldWideSites.aspx"  bi:cpid="dlcmenu">
                                                            <span>Worldwide Download Centers</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/share-downloads.aspx"  bi:cpid="dlcmenu">
                                                            <span>Share downloads</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/faq.aspx"  bi:cpid="dlcmenu">
                                                            <span>FAQ</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                                <li class="mstNavMenuListItem">
                                                    <div bi:type="oneMscomNavMenuItem">
                                                        <a href="http://www.microsoft.com/en-us/download/rsscontent.aspx"  bi:cpid="dlcmenu">
                                                            <span>RSS Feeds</span>
                                                        </a>
                                                    </div>                                                                                        
                                                </li>
                                            
                                    </ul>
                                    
            
            </li>
           </ul> 

       
           <ul class="mstNav4ColFlyoutList mstNav4ColMiddle">
            <li>
            
               
            
            </li>
           </ul> 

       
           <ul class="mstNav4ColFlyoutList mstNav4ColMiddle">
            <li>
            
               
            
            </li>
           </ul> 

       
           <ul class="mstNav4ColFlyoutList mstNav4ColMiddle">
            <li>
            
               
            
            </li>
           </ul> 

       




</div></div></li></ul>
    </div>
</div>

<script type="text/javascript">

    if (typeof $ != "undefined") {
        $(function () {
            if (Mst && Mst.FlyoutNavigationMenuV3) {
                var NavigationMenuV3 = new Mst.FlyoutNavigationMenuV3('ctl00_ctl11_ctl07_ctl00', '916', '');
            }

        });
    }

</script>

            </div>
        </div>
        <div class="mstHdr_BrandLine">
        </div>
    </div>
</div>
<script type="text/javascript">
    if (typeof $ != "undefined") {
        $(function () {
            if (Mst && Mst.HeaderV3) {
               
                var blade3V = new Mst.HeaderV3('ctl00_ctl11_mstHdrV3', '916', '');
            }
        });
    }
</script>

                    
                </div>
                
            </div>
            <div class="hpMst_StageInner">
                
                <div class="hpMst_Content" bi:type="hpPage">
                    <script type="text/javascript" src="http://Ads1.msn.com/library/dap.js"></script>
                    

<div bi:type="hpGrid" bi:parenttitle="item" class="hpGrd_Grid">
    
            <div id="ctl00_ctl19_ColumnRepeater_ctl00_Column" class="hpGrd_Column hpGrd_Span92 dh-col" bi:gridindex="0" bi:gridtype="column">
                
                        <div id="ctl00_ctl19_ColumnRepeater_ctl00_RowRepeater_ctl00_Row" class="hpGrd_Row hpGrd_RowNoMargin " bi:gridindex="0" bi:gridtype="row">
                            
                                    <div id="ctl00_ctl19_ColumnRepeater_ctl00_RowRepeater_ctl00_CellRepeater_ctl00_Cell" class="hpGrd_Cell hpGrd_Span77 hpGrd_CellNoMargin" bi:gridindex="0" bi:gridtype="cell">
                                        

<div id="ctl00_ctl19_ColumnRepeater_ctl00_RowRepeater_ctl00_CellRepeater_ctl00_ctl01" class="chdr"  bi:titleflag="item">
    <div class="chdr-icon"><img src="http://i.microsoft.com/global/ImageStore/PublishingImages/logos/56x56/windows_symbol_clr_56x56.png" alt="Windows" /></div>
    <div class="chdr-p">
        <h1 bi:title="item" id="top">Security Update for Windows XP/Vista/7 (KB2753842)</h1>
    </div>
</div>
<script type="text/javascript">
    $("div.mstSocial_Wrapper").ready(function () {
        if (!(jQuery.browser.msie && jQuery.browser.version == 6)) {
            $("div.mstSocial_Wrapper").css({ display: "block", "padding-top": "4px" });
        }
    });
</script>

                                        <div class="hpGrd_Filler"></div>
                                    </div>
                                
                                    <div id="ctl00_ctl19_ColumnRepeater_ctl00_RowRepeater_ctl00_CellRepeater_ctl01_Cell" class="hpGrd_Cell hpGrd_Span14" bi:gridindex="1" bi:gridtype="cell">
                                        <div class="mstSocial_Wrapper"><div id="HorizontalLayout" style="width:100%; overflow:hidden;"><div id="HorizontalControlWrapper" style="float: right;"></div></div><div id="SocialControlBase" style="float: right;"><div id="ctl00_ctl19_ColumnRepeater_ctl00_RowRepeater_ctl00_CellRepeater_ctl01_ctl01_mstSocialHolderCtl" class="onsMscomSocialHolder" style="margin-top:5px;">
<div id="ctl00_ctl19_ColumnRepeater_ctl00_RowRepeater_ctl00_CellRepeater_ctl01_ctl01_mstSocialCtl" class="oneMscomComp oneMscomSocial" style="border-color:white;background-color:white;float:right;background:rgba(255, 255, 255,1);filter:alpha(opacity=100);" bi:type="oneMscomSocial"><ul class="social-section"><li class="social-item" id="li_mstSocialRss" style="float: left;"bi:type="oneMscomRss" ><div class="social-item-tab-clickable"><a href="http://www.microsoft.com/en-us/download/rsscontent.aspx"  target="_blank" class="social-flyout-link" title="Rss" id="mstSocialRss" ><img src="http://www.microsoft.com/global/onemscomsettings/publishingimages/socialimages/rss.png" /></a></div></li><li class="social-item" id="li_mstSocialShare" style="float: left;"bi:type="oneMscomShare" ><div class="social-item-tab-clickable"><a href="http://www.microsoft.com/en-us/download/details.aspx?id=35845&amp;socialIndexctl00_ctl19_ColumnRepeater_ctl00_RowRepeater_ctl00_CellRepeater_ctl01_ctl01Share=mstSocialSharectl00_ctl19_ColumnRepeater_ctl00_RowRepeater_ctl00_CellRepeater_ctl01_ctl01Share" class="social-flyout-link" title="Share" id="mstSocialShare" bi:track="false" ><img src="http://www.microsoft.com/global/onemscomsettings/publishingimages/socialimages/share.png" /></a></div><div class="social-item-flyout-clickable"  ><div class="mstSocial_Share_Popup mstSocial_Share_Popup_ctl00_ctl19_ColumnRepeater_ctl00_RowRepeater_ctl00_CellRepeater_ctl01_ctl01Share col1" ><div class="mstSocial_Share_Popup_Header mstSocial_Share_Popup_Header_ctl00_ctl19_ColumnRepeater_ctl00_RowRepeater_ctl00_CellRepeater_ctl01_ctl01Share" ><div class="mstSocial_Share_Popup_Header_Title">Share</div><div class="mstSocial_Share_Popup_Header_Close"><a id="mstSocialSharePopupClose" href="http://www.microsoft.com/en-us/download/details.aspx?id=35845&amp;socialIndexctl00_ctl19_ColumnRepeater_ctl00_RowRepeater_ctl00_CellRepeater_ctl01_ctl01Share=mstSocialSharectl00_ctl19_ColumnRepeater_ctl00_RowRepeater_ctl00_CellRepeater_ctl01_ctl01Share" bi:track="false"><img src="http://www.microsoft.com/global/onemscomsettings/publishingimages/commonimages/flyoutclosebutton.png" /></a></div></div><div class="mstSocial_Share_Popup_Content mstSocial_Share_Popup_Content_ctl00_ctl19_ColumnRepeater_ctl00_RowRepeater_ctl00_CellRepeater_ctl01_ctl01Share" ><ul class="mstSocial_Share_Items_l1"><li><a id="si_8" href="mailto:?subject=Download Security Update for Windows XP (KB2753842) from Official Microsoft Download Center&amp;body=http%3a%2f%2fwww.microsoft.com%2fen-us%2fdownload%2fdetails.aspx%3fid%3d35845" target="_blank"   ><span class="mstSocial_Share_Item_Icon_Container"><img class="mstSocial_Share_Item_Icon_Img si_8" src="http://www.microsoft.com/global/onemscomsettings/publishingimages/socialimages/spr-icons.png" /></span><span class="mstSocial_Share_Item_Name">Email</span></a></li><li><a id="si_31" href="http://www.hotmail.msn.com/secure/start?action=compose&to=&subject=Download+Security+Update+for+Windows+XP+(KB2753842)+from+Official+Microsoft+Download+Center&body=http%3a%2f%2fwww.microsoft.com%2fen-us%2fdownload%2fdetails.aspx%3fid%3d35845" target="_blank"   ><span class="mstSocial_Share_Item_Icon_Container"><img class="mstSocial_Share_Item_Icon_Img si_31" src="http://www.microsoft.com/global/onemscomsettings/publishingimages/socialimages/spr-icons.png" /></span><span class="mstSocial_Share_Item_Name">Hotmail</span></a></li><li><a id="si_5" href="http://www.blogger.com/blog_this.pyra?t=&u=http%3a%2f%2fwww.microsoft.com%2fen-us%2fdownload%2fdetails.aspx%3fid%3d35845&n=http%3a%2f%2fwww.microsoft.com%2fen-us%2fdownload%2fdetails.aspx%3fid%3d35845" target="_blank"   ><span class="mstSocial_Share_Item_Icon_Container"><img class="mstSocial_Share_Item_Icon_Img si_5" src="http://www.microsoft.com/global/onemscomsettings/publishingimages/socialimages/spr-icons.png" /></span><span class="mstSocial_Share_Item_Name">Blogger</span></a></li><li><a id="si_1" href="http://connect.aim.com/share/?url=http%3a%2f%2fwww.microsoft.com%2fen-us%2fdownload%2fdetails.aspx%3fid%3d35845&title=Download+Security+Update+for+Windows+XP+(KB2753842)+from+Official+Microsoft+Download+Center" target="_blank"   ><span class="mstSocial_Share_Item_Icon_Container"><img class="mstSocial_Share_Item_Icon_Img si_1" src="http://www.microsoft.com/global/onemscomsettings/publishingimages/socialimages/spr-icons.png" /></span><span class="mstSocial_Share_Item_Name">AOL</span></a></li><li><a id="si_10" href="http://www.facebook.com/sharer.php?u=http%3a%2f%2fwww.microsoft.com%2fen-us%2fdownload%2fdetails.aspx%3fid%3d35845&t=Download+Security+Update+for+Windows+XP+(KB2753842)+from+Official+Microsoft+Download+Center" target="_blank"   ><span class="mstSocial_Share_Item_Icon_Container"><img class="mstSocial_Share_Item_Icon_Img si_10" src="http://www.microsoft.com/global/onemscomsettings/publishingimages/socialimages/spr-icons.png" /></span><span class="mstSocial_Share_Item_Name">Facebook</span></a></li></ul></div></div></div></li></ul></div>
    <div id="mstSocialCtlclear" class="cssClear">
    </div>
</div>
<script type="text/javascript">if (typeof $ != "undefined") {$(function () {if (Mst && Mst.SocialFlyout) {var Social = new Mst.SocialFlyout('ctl00_ctl19_ColumnRepeater_ctl00_RowRepeater_ctl00_CellRepeater_ctl01_ctl01_mstSocialCtl');}});}</script></div><div class="cssClear"></div></div>
                                        <div class="hpGrd_Filler"></div>
                                    </div>
                                
                            <div class="hpGrd_Filler"></div>
                        </div>
                    
                        <div id="ctl00_ctl19_ColumnRepeater_ctl00_RowRepeater_ctl01_Row" class="hpGrd_Row " bi:gridindex="1" bi:gridtype="row">
                            
                                    <div id="ctl00_ctl19_ColumnRepeater_ctl00_RowRepeater_ctl01_CellRepeater_ctl00_Cell" class="hpGrd_Cell hpGrd_Span92 hpGrd_CellNoMargin" bi:gridindex="0" bi:gridtype="cell">
                                        <div class="dsp-xhtml">
    <div class="clear-breakline"></div>
    <div class="left-breakline"></div>
    </div>
                                        <div class="hpGrd_Filler"></div>
                                    </div>
                                
                            <div class="hpGrd_Filler"></div>
                        </div>
                    
            </div>
        
</div>
<script type="text/javascript">
    if (typeof $ != 'undefined' && Hp && Hp.Grid) {
        $(document).ready(Hp.Grid.init);
    } 
</script>


<div bi:type="hpGrid" bi:parenttitle="item" class="hpGrd_Grid">
    
            <div id="ctl00_ctl20_ColumnRepeater_ctl00_Column" class="hpGrd_Column hpGrd_Span92 " bi:gridindex="0" bi:gridtype="column">
                
                        <div id="ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl00_Row" class="hpGrd_Row hpGrd_RowNoMargin " bi:gridindex="0" bi:gridtype="row">
                            
                            <div class="hpGrd_Filler"></div>
                        </div>
                    
                        <div id="ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl01_Row" class="hpGrd_Row " bi:gridindex="1" bi:gridtype="row">
                            
                                    <div id="ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl01_CellRepeater_ctl00_Cell" class="hpGrd_Cell hpGrd_Span92 hpGrd_CellNoMargin" bi:gridindex="0" bi:gridtype="cell">
                                        


<div style="display:none;visibility:hidden;">
    <object classid='clsid:17492023-C23A-453E-A040-C7C580BBF700' 
        id='LegitCheck' codebase='#version=1,9,0042,0' viewastext=''>
	</object>
</div>

<input id='gaflag' name='gaflag' type='hidden' value=''/>
<input id='blobhash' name='blobhash' type='hidden' value=''/>

<script type='text/javascript'>
    var g_DateCode = '3375b1e3-8015-009b-3da2-e45cc1cba7b9';
    var g_IEValidationPage = 'genuine-validation.aspx';
    var g_ExeValidationPage = 'exe-validation.aspx';
    var g_autocheck = false;
    
    function isIE() {
        return $.browser.msie;
    }

    function submitBlob() {
        var blob = getBlob();
        if (blob != null) {
            var elm = document.getElementById('blobhash');
            elm.value = blob;
            var frm = document.getElementById('aspnetForm');
            var flag = document.getElementById('gaflag');
            flag.value = 'true';
            frm.submit();
            return true;
        }
        return false;
    }

    function DoWGA(pid) {  
        if (!submitBlob()) {
            return goToValidationPage(pid);
        }
        return false;
    }

    function getBlob() {
        if (isIE()) {
            try {
                var LegitCheck = document.getElementById('LegitCheck');
                LegitCheck.HashCode = g_DateCode;
                return LegitCheck.GetBlob(g_DateCode);
            }
            catch (e) {
                return null;
            }
        }
    }

    function goToValidationPage(pid){
        var frm = $('#aspnetForm');
        frm.submit(function(e) {
            stopEvent(e);
        });
        
        if(isIE()){
            window.location.href = g_IEValidationPage + "?id=" + pid;
        }
        else{
            window.location.href = g_ExeValidationPage + "?id=" + pid;
        }
        return false;
    }

    function stopEvent(e) {
        if (e.stopPropagation) e.stopPropagation();
        else e.cancelBubble = true;
        
        if (e.preventDefault) e.preventDefault();
        else e.returnValue = false;
    }

    
</script>

<script type='text/javascript'>
    $().ready(function () {
        if (g_autocheck) {
            if (isIE()) {
                submitBlob();
            }
            else {
                goToValidationPage('35845');
            }
        }
    });
</script>

<div id="ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl01_CellRepeater_ctl00_ctl01" class="details">
    <div id="top"></div>
    <div class="details-nav">
        <h4 bi:titleflag="item" bi:title="item">Quick links</h4>
        <ul bi:parenttitle="item">
            
            <li><a href="index.html#overview">Overview</a></li>
            
            <li><a href="index.html#system-requirements">System requirements</a></li>
            
            <li><a href="index.html#instructions">Instructions</a></li>
            
            <li><a href="index.html#additional-information">Additional information</a></li>
            
        </ul>
        
        <div class="fixit">
            <h4>Looking for support?</h4>
            <div class="image">
                <a href="http://support.microsoft.com/" id="ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl01_CellRepeater_ctl00_ctl01_FixitImageLink" bi:LinkId="000-00-000AAAA000000" bi:CampaignName="(support_microsoft_com fixit)">
                    <img src="http://i.microsoft.com/global/en-us/download/PublishingImages/fixit_icon.png" alt="Visit the Microsoft Support site now >" /></a>
            </div>
            <div class="link"><a href="http://support.microsoft.com/" id="ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl01_CellRepeater_ctl00_ctl01_FixitTextLink" bi:LinkId="000-00-000AAAA000000" bi:CampaignName="(support_microsoft_com fixit)">Visit the Microsoft Support site now ></a></div>
        </div>
        
        <div class="adplacement" id="divAdPlacement" style="clear: both;">
            

<div id="ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl01_CellRepeater_ctl00_ctl01_ctl01" class="hpAd" bi:type="hpAd">
    
        <script type="text/javascript">
            var renderAd = function() {
                try {
                    dapMgr.enableACB('ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl01_CellRepeater_ctl00_ctl01_ctl01', false);
                    dapMgr.renderAd('ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl01_CellRepeater_ctl00_ctl01_ctl01', 
                        '&PG=CMSDCB&AP=1087', 
                        180, 150);
                } catch (e) { }
            };

            if ($.browser.mozilla) {
                
                setTimeout(renderAd, 0);
            }
            else {
                renderAd();
            }
        </script>
    
</div>

        </div>
    </div>
    
    <div class="details-info" itemtype="http://schema.org/Product" itemscope="">
        <meta itemprop="name" content="Security Update for Windows XP (KB2753842)">
        <meta itemprop="image" content="http://www.microsoft.com/global/ImageStore/PublishingImages/logos/56x56/windows_symbol_clr_56x56.png">
        <meta itemprop="url" content="http://www.microsoft.com/en-us/download/details.aspx?id=35845">
        <meta itemprop="id" content="35845">
    <h4 id="ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl01_CellRepeater_ctl00_ctl01_Description" class="description" itemprop="description">A security issue has been identified that could allow an unauthenticated remote attacker to compromise your system and gain control over it.</h4>

        


        <div class="qdtl" style="margin-bottom: 22px">
            <div class="qdtl-inner">
                <h2 bi:titleflag="item" bi:title="item">Quick details</h2>
                <div class="qdtl-info" bi:parenttitle="item">
                    <table class="properties">
                        <colgroup>
                            <col class="col1" />
                            <col class="col2" />
                            <col class="col3" />
                            <col class="col4" />
                        </colgroup>
                        <tr>
                            <td class="col1"><strong>Version:</strong></td>
                            <td class="col2"><span>2753842</span></td>
                            <td class="col3"><strong>Date published:</strong></td>
                            <td class="col4"><span>12/10/2012</span></td>
                        </tr>
                        <tr>
                            
                            <td class="col1" bi:titleflag="item" bi:title="item">
                                <label for="change-language"><strong>Change language:</strong></label></td>
                            <td class="col234" colspan="3" bi:parenttitle="item">
                                <select id="change-language" name="change-language" data-autopostback="true">
                                    
                                    <option value="4">Arabic</option>
                                    
                                    <option value="17">Chinese (Simplified)</option>
                                    
                                    <option value="19">Chinese (Traditional)</option>
                                    
                                    <option value="21">Czech</option>
                                    
                                    <option value="22">Danish</option>
                                    
                                    <option value="24">Dutch</option>
                                    
                                    <option value="25" selected="selected">English</option>
                                    
                                    <option value="29">Finnish</option>
                                    
                                    <option value="30">French</option>
                                    
                                    <option value="34">German</option>
                                    
                                    <option value="35">Greek</option>
                                    
                                    <option value="38">Hebrew</option>
                                    
                                    <option value="40">Hungarian</option>
                                    
                                    <option value="45">Italian</option>
                                    
                                    <option value="46">Japanese</option>
                                    
                                    <option value="54">Korean</option>
                                    
                                    <option value="69">Norwegian (Bokmål)</option>
                                    
                                    <option value="73">Polish</option>
                                    
                                    <option value="74">Portuguese (Brazil)</option>
                                    
                                    <option value="75">Portuguese (Portugal)</option>
                                    
                                    <option value="80">Russian</option>
                                    
                                    <option value="89">Spanish</option>
                                    
                                    <option value="90">Swedish</option>
                                    
                                    <option value="96">Turkish</option>
                                    
                                </select>
                                <noscript>
                                    <input type="submit" name="ctl00$ctl20$ColumnRepeater$ctl00$RowRepeater$ctl01$CellRepeater$ctl00$ctl01$BtnChangeLanguage" value="Change" id="ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl01_CellRepeater_ctl00_ctl01_BtnChangeLanguage" />
                                </noscript>
                            </td>
                            
                        </tr>
                    </table>
                </div>

                
                <div class="qdtl-articles" bi:parenttitle="item">
                    <table class="articles">
                        <colgroup>
                            <col class="col1" />
                            <col class="col234" />
                        </colgroup>
                        
                        <tr>
                            <td class="col1" bi:titleflag="item" bi:title="item"><strong>KB articles:</strong></td>
                            <td class="col234" bi:parenttitle="item"><a href='http://support.microsoft.com/kb/2753842'>KB2753842</a></td>
                        </tr>
                        
                        <tr>
                            <td class="col1" bi:titleflag="item" bi:title="item"><strong>Security bulletins:</strong></td>
                            <td class="col234" bi:parenttitle="item"><a href='http://technet.microsoft.com/en-us/security/Bulletin/MS12-078'>MS12-078</a></td>
                        </tr>
                        
                    </table>
                </div>
                

                <table class="files">
                    <colgroup>
                        <col class="file-name" />
                        <col class="size" />
                        <col class="download" />
                    </colgroup>
                    <tr>
                        <th>File name</th>
                        <th>Size</th>
                        <th></th>
                    </tr>

                    
                    <tr>
                        <td class="file-name" bi:titleflag="item" bi:title="item"><span>WindowsXP-KB2753842-x86-ENU.exe</span></td>
                        <td class="size"><span>649 KB</span></td>
                        <td class="download" bi:parenttitle="item">


                            
                            <a class="download" onclick="return false;" href="Windows-KB2753842-ENU.exe" bi:fileurl="http://download.microsoft.com/download/5/4/B/54BF07C1-F780-4C28-A578-E64032DFB034/WindowsXP-KB2753842-x86-ENU.exe"
                                bi:displaylang="en" bi:track="false"><span>Download</span></a>
                            
                        </td>
                    </tr>

                    
                </table>

                <div class="feature-items" bi:parenttitle="item" id="divProductOffer">
                    <div id="ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl01_CellRepeater_ctl00_ctl01_ctl03_productOfferID_clientID" class="omniLst productOfferLst omniLst_styleProductOffer" bi:type="dlcProductOffer">
    <div class="omniLst_body" >
        <div class="pos1_item" index="0" bi:itemindex="0">
            <div id="ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl01_CellRepeater_ctl00_ctl01_ctl03_productOfferID_featureItem1_Container" class="hpFeat_FeatureItem hpFeat_Pos-left" bi:type="hpfeatureitem">
        <div id="ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl01_CellRepeater_ctl00_ctl01_ctl03_productOfferID_featureItem1_Image" class="hpFeat_ImageContainer" bi:parenttitle="item">
            <a href="http://update.microsoft.com/microsoftupdate"  bi:campaignname="(Microsoft Update)" bi:linkid="200-00-121LSUS007997" bi:type="image" class="hpImage_Link"><img src="http://i.microsoft.com/global/ImageStore/PublishingImages/Asset/thumbnails/WinUpdate_sm.png" alt="Get the latest updates for your PC at Microsoft Update."  width="70" height="70" class="hpImage_Img"/></a>
        </div>
        <div id="ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl01_CellRepeater_ctl00_ctl01_ctl03_productOfferID_featureItem1_TextContainer" class="hpFeat_ItemContainer" bi:titleflag="item" style="margin-right:85px;">
            

            <h5 class="hpFeat_Wrap hpFeat_Title hpFeat_Item" bi:titleflag="item" bi:title="item"><a class="hpFeat_Link"  bi:campaignname="(Microsoft Update)" bi:linkid="200-00-121LSUS007997" bi:type="title"   href="http://update.microsoft.com/microsoftupdate">Microsoft Update</a></h5>

            <p class="hpFeat_Wrap hpFeat_Description hpFeat_Item noLink" bi:parenttitle="item">Check for the latest security updates to help protect your computer.</p>

            
            

            

            

            <ul id="ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl01_CellRepeater_ctl00_ctl01_ctl03_productOfferID_featureItem1_PrimaryCta" class="hpFeat_PrimaryCta hpFeat_Item" bi:parenttitle="item">
                
                    <li >
                        <a class="hpFeat_Link Arrow"  bi:campaignname="(Microsoft Update)" bi:linkid="200-00-121LSUS007997" bi:index="0" bi:type="primarycta"   href="http://update.microsoft.com/microsoftupdate"><span class="hpFeat_Text">Download now</span><span class="hpFeat_Arrow" >&#155;</span></a>
                    </li>
                </ul>

            
        </div>
    </div>

        </div>
        
        <div class="pos2_item" index="1" bi:itemindex="1">
            

        </div>
        <div style="clear:both;"></div>
    </div>
</div>



                </div>
            </div>
        </div>
        <div class="details-article">
            
            <h2 id="overview" bi:titleflag="item1" bi:title="item1">Overview</h2>
            <p>A security issue has been identified that could allow an unauthenticated remote attacker to compromise your system and gain control over it. You can help protect your system by installing this update from Microsoft. After you install this update, you may have to restart your system.</p>
            <img alt="Top of page" src="http://i.microsoft.com/en-us/download/shared/templates/components/omnidetails/images/arrow_anchorlink_up.png" /><a href="index.html#top" class="to-top" bi:parenttitle="item1"><span>Top of page</span></a>
            
            <h2 id="system-requirements" bi:titleflag="item2" bi:title="item2">System requirements</h2>
            
            <p><strong>Supported operating systems:</strong> Windows XP Service Pack 3</p>
            
            <p><br/></p>
            
            <img alt="Top of page" src="http://i.microsoft.com/en-us/download/shared/templates/components/omnidetails/images/arrow_anchorlink_up.png" /><a href="index.html#top" class="to-top" bi:parenttitle="item2"><span>Top of page</span></a>
            
            <h2 id="instructions" bi:titleflag="item3" bi:title="item3">Instructions</h2>
            <p><ol><li>To start the download, click the <b>Download</b> button and then do one of the following, or select another language from <b>Change Language</b> and then click <b>Change</b>.</li><ul><li>Click <b>Run</b> to start the installation immediately.</li><li>Click <b>Save</b> to copy the download to your computer for installation at a later time.</li></ul></ol></p>
            <img alt="Top of page" src="http://i.microsoft.com/en-us/download/shared/templates/components/omnidetails/images/arrow_anchorlink_up.png" /><a href="index.html#top" class="to-top" bi:parenttitle="item3"><span>Top of page</span></a>
            
            <h2 id="additional-information" bi:titleflag="item4" bi:title="item4">Additional information</h2>
            <p><b>Other critical security updates are available:</b> To find the latest security updates for you, visit <a HREF='http://update.microsoft.com'>Windows Update</a> and click <b>Express Install</b>. To have the latest security updates delivered directly to your computer, visit the <a HREF='http://go.microsoft.com/fwlink/?LinkId=82023'>Security At Home</a> web site and follow the steps to ensure you're protected.</p>
            <img alt="Top of page" src="http://i.microsoft.com/en-us/download/shared/templates/components/omnidetails/images/arrow_anchorlink_up.png" /><a href="index.html#top" class="to-top" bi:parenttitle="item4"><span>Top of page</span></a>
            
        </div>
    </div>
    <div class="cssClear"></div>
    
</div>
<script type="text/javascript">   
    var baseFamilyId = "e4a2cd3b-598b-4cf4-8b42-2582d369bab5";
    var dwntype = "SinDwn";
    var cultureCode = "en-us";
    var displayLang = "en" ;
    var downloadFileUrl = "http://download.microsoft.com/download/5/4/B/54BF07C1-F780-4C28-A578-E64032DFB034/WindowsXP-KB2753842-x86-ENU.exe" ;
    var productId = '35845';
    $(function(){  
        $.bi.baseData({"familyid": baseFamilyId});               
        $.bi.baseData({"cultureCode": cultureCode });
        $.bi.baseData({"downloadSource":"DLC" });                                
        $.bi.baseData({"dwntype": dwntype});                                
        $.bi.baseData({"displayLang": displayLang});
        $.bi.baseData({"dlfileurl": downloadFileUrl}); 

        if(dwntype === "BundleDwn")
        {
            $.bi.baseData({"dlcfamilyid_parent": baseFamilyId});                                
        }
    });

    //after pageload, remove dwntype value from BI so click events dont send dwntype
    $(window).load(function(){
        $.bi.baseData({"dwntype": ''}); 
    });
  
    Ms.Details();
    $("#ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl01_CellRepeater_ctl00_ctl01").details({ "downloadUrl": "http://download.microsoft.com/download/5/4/B/54BF07C1-F780-4C28-A578-E64032DFB034/WindowsXP-KB2753842-x86-ENU.exe", "enableAtlasActionTag": true, "atlasActionTag": ""
        ,"BIOfferName":"ppd","BIFilterID":"SinDwn"
        ,"changelangScript":"__doPostBack('ctl00$ctl20$ColumnRepeater$ctl00$RowRepeater$ctl01$CellRepeater$ctl00$ctl01$BtnChangeLanguage','')"});
</script>

                                        <div class="hpGrd_Filler"></div>
                                    </div>
                                
                            <div class="hpGrd_Filler"></div>
                        </div>
                    
                        <div id="ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl02_Row" class="hpGrd_Row " bi:gridindex="2" bi:gridtype="row">
                            
                            <div class="hpGrd_Filler"></div>
                        </div>
                    
                        <div id="ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl03_Row" class="hpGrd_Row " bi:gridindex="3" bi:gridtype="row">
                            
                            <div class="hpGrd_Filler"></div>
                        </div>
                    
                        <div id="ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl04_Row" class="hpGrd_Row " bi:gridindex="4" bi:gridtype="row">
                            
                                    <div id="ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl04_CellRepeater_ctl00_Cell" class="hpGrd_Cell hpGrd_Span92 hpGrd_CellNoMargin" bi:gridindex="0" bi:gridtype="cell">
                                        

<div bi:type="hpGrid" bi:parenttitle="item" class="hpGrd_Grid">
    
            <div id="ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl04_CellRepeater_ctl00_ctl01_ctl00_ColumnRepeater_ctl00_Column" class="hpGrd_Column hpGrd_Span92 " bi:gridindex="0" bi:gridtype="column">
                
                        <div id="ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl04_CellRepeater_ctl00_ctl01_ctl00_ColumnRepeater_ctl00_RowRepeater_ctl00_Row" class="hpGrd_Row hpGrd_RowNoMargin " bi:gridindex="0" bi:gridtype="row">
                            
                                    <div id="ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl04_CellRepeater_ctl00_ctl01_ctl00_ColumnRepeater_ctl00_RowRepeater_ctl00_CellRepeater_ctl00_Cell" class="hpGrd_Cell hpGrd_Span22 hpGrd_CellNoMargin" bi:gridindex="0" bi:gridtype="cell">
                                        <div id="ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl04_CellRepeater_ctl00_ctl01_ctl00_ColumnRepeater_ctl00_RowRepeater_ctl00_CellRepeater_ctl00_RelatedLinks1_clientID" class="hpLst hpLst_style1" bi:type="hpList">
    <div class="hpLst_box">
        <h3 class="hpFeat_Wrap hpLst_title noLink" bi:titleflag="item" bi:title="item">Related resources</h3>
        
        <div class="hpLst_body" bi:parenttitle="item">
            <ul>
                
                <li bi:index="0">
                    <div id="ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl04_CellRepeater_ctl00_ctl01_ctl00_ColumnRepeater_ctl00_RowRepeater_ctl00_CellRepeater_ctl00_RelatedLinks1_featureItemID_Container" class="hpFeat_FeatureItem hpFeat_Pos-noimage" bi:type="hpfeatureitem">
        
        <div id="ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl04_CellRepeater_ctl00_ctl01_ctl00_ColumnRepeater_ctl00_RowRepeater_ctl00_CellRepeater_ctl00_RelatedLinks1_featureItemID_TextContainer" class="hpFeat_ItemContainer">
            

            

            

            
            

            

            

            

            <ul id="ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl04_CellRepeater_ctl00_ctl01_ctl00_ColumnRepeater_ctl00_RowRepeater_ctl00_CellRepeater_ctl00_RelatedLinks1_featureItemID_SecondaryCta" class="hpFeat_SecondaryCta hpFeat_Item">
                
                
                    <li>
                        <a class="hpFeat_Link Arrow"  bi:index="0" bi:type="secondarycta"   href="http://go.microsoft.com/fwlink/?LinkId=271624"><span class="hpFeat_Text">Microsoft Security Bulletin</span><span class="hpFeat_Arrow" >&#155;</span></a>
                    </li>
                </ul>
        </div>
    </div>

                </li>
                
            </ul>
        </div>
        
    </div>
</div>

                                        <div class="hpGrd_Filler"></div>
                                    </div>
                                
                                    <div id="ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl04_CellRepeater_ctl00_ctl01_ctl00_ColumnRepeater_ctl00_RowRepeater_ctl00_CellRepeater_ctl01_Cell" class="hpGrd_Cell hpGrd_Span22" bi:gridindex="1" bi:gridtype="cell">
                                        <div id="ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl04_CellRepeater_ctl00_ctl01_ctl00_ColumnRepeater_ctl00_RowRepeater_ctl00_CellRepeater_ctl01_AffinityDownloads1_clientID" class="hpLst hpLst_style1" bi:type="hpList">
    <div class="hpLst_box">
        <h3 class="hpFeat_Wrap hpLst_title noLink" bi:titleflag="item" bi:title="item">What others are downloading</h3>
        
        <div class="hpLst_body" bi:parenttitle="item">
            <ul>
                
                <li bi:index="0">
                    <div id="ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl04_CellRepeater_ctl00_ctl01_ctl00_ColumnRepeater_ctl00_RowRepeater_ctl00_CellRepeater_ctl01_AffinityDownloads1_featureItemID_Container" class="hpFeat_FeatureItem hpFeat_Pos-noimage" bi:type="hpfeatureitem">
        
        <div id="ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl04_CellRepeater_ctl00_ctl01_ctl00_ColumnRepeater_ctl00_RowRepeater_ctl00_CellRepeater_ctl01_AffinityDownloads1_featureItemID_TextContainer" class="hpFeat_ItemContainer">
            

            

            

            
            

            

            

            

            <ul id="ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl04_CellRepeater_ctl00_ctl01_ctl00_ColumnRepeater_ctl00_RowRepeater_ctl00_CellRepeater_ctl01_AffinityDownloads1_featureItemID_SecondaryCta" class="hpFeat_SecondaryCta hpFeat_Item">
                
                
                    <li>
                        <a class="hpFeat_Link Arrow"  bi:index="0" bi:type="secondarycta"   href="http://www.microsoft.com/en-us/download/details.aspx?id=35863"><span class="hpFeat_Text">Security Update for Windows XP (KB2779030)</span><span class="hpFeat_Arrow" >&#155;</span></a>
                    </li>
                
                    <li>
                        <a class="hpFeat_Link Arrow"  bi:index="1" bi:type="secondarycta"   href="http://www.microsoft.com/en-us/download/details.aspx?id=35926"><span class="hpFeat_Text">Security Update for Windows XP (KB2758857)</span><span class="hpFeat_Arrow" >&#155;</span></a>
                    </li>
                
                    <li>
                        <a class="hpFeat_Link Arrow"  bi:index="2" bi:type="secondarycta"   href="http://www.microsoft.com/en-us/download/details.aspx?id=35872"><span class="hpFeat_Text">Security Update for Windows XP (KB2770660)</span><span class="hpFeat_Arrow" >&#155;</span></a>
                    </li>
                
                    <li>
                        <a class="hpFeat_Link Arrow"  bi:index="3" bi:type="secondarycta"   href="http://www.microsoft.com/en-us/download/details.aspx?id=35962"><span class="hpFeat_Text">Cumulative Security Update for Internet Explorer 8 for Windows XP (KB2761465)</span><span class="hpFeat_Arrow" >&#155;</span></a>
                    </li>
                
                    <li>
                        <a class="hpFeat_Link Arrow"  bi:index="4" bi:type="secondarycta"   href="http://www.microsoft.com/en-us/download/details.aspx?id=35934"><span class="hpFeat_Text">Cumulative Security Update for Internet Explorer for Windows XP (KB2761465)</span><span class="hpFeat_Arrow" >&#155;</span></a>
                    </li>
                
                    <li>
                        <a class="hpFeat_Link Arrow"  bi:index="5" bi:type="secondarycta"   href="http://www.microsoft.com/en-us/download/details.aspx?id=35780"><span class="hpFeat_Text">Update for Windows XP (KB2779562)</span><span class="hpFeat_Arrow" >&#155;</span></a>
                    </li>
                </ul>
        </div>
    </div>

                </li>
                
            </ul>
        </div>
        
    </div>
</div>

                                        <div class="hpGrd_Filler"></div>
                                    </div>
                                
                            <div class="hpGrd_Filler"></div>
                        </div>
                    
            </div>
        
</div>
<script type="text/javascript">
    if (typeof $ != 'undefined' && Hp && Hp.Grid) {
        $(document).ready(Hp.Grid.init);
    } 
</script>

                                        <div class="hpGrd_Filler"></div>
                                    </div>
                                
                            <div class="hpGrd_Filler"></div>
                        </div>
                    
                        <div id="ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl05_Row" class="hpGrd_Row " bi:gridindex="5" bi:gridtype="row">
                            
                                    <div id="ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl05_CellRepeater_ctl00_Cell" class="hpGrd_Cell hpGrd_Span9 hpGrd_CellNoMargin" bi:gridindex="0" bi:gridtype="cell">
                                        
                                        <div class="hpGrd_Filler"></div>
                                    </div>
                                
                                    <div id="ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl05_CellRepeater_ctl01_Cell" class="hpGrd_Cell hpGrd_Span73" bi:gridindex="1" bi:gridtype="cell">
                                        

<div id="ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl05_CellRepeater_ctl01_ctl01" class="hpAd" bi:type="hpAd">
    
        <script type="text/javascript">
            var renderAd = function() {
                try {
                    dapMgr.enableACB('ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl05_CellRepeater_ctl01_ctl01', false);
                    dapMgr.renderAd('ctl00_ctl20_ColumnRepeater_ctl00_RowRepeater_ctl05_CellRepeater_ctl01_ctl01', 
                        '&PG=CMSDCI&AP=1390', 
                        728, 90);
                } catch (e) { }
            };

            if ($.browser.mozilla) {
                
                setTimeout(renderAd, 0);
            }
            else {
                renderAd();
            }
        </script>
    
</div>

                                        <div class="hpGrd_Filler"></div>
                                    </div>
                                
                            <div class="hpGrd_Filler"></div>
                        </div>
                    
            </div>
        
</div>
<script type="text/javascript">
    if (typeof $ != 'undefined' && Hp && Hp.Grid) {
        $(document).ready(Hp.Grid.init);
    } 
</script>

<script type="text/javascript">   
    var geoRedirectAjaxUrl = "/en-us/download/components/geo/georedirect.asch?id=35845";
</script>
                </div>
                <div class="hpMst_Footer">
                    
                    <div class="omniMst_V3HeaderFooterContainer">
                        <div id="ctl00_ctl24_mstFooterV3Ctl" class="oneMscomFooterV3" bi:type="oneMscomFooter">
        <div id="mstFooterV3Backround" class="mstFooterV3Backround"></div>
        <div class="mstFooterTop">
            <div id="ctl00_ctl24_mstFooterMsLink" class="mstFooterMsLink" bi:type="oneMscomFooterMsLink">
                <ul class="mstFooterMsLinkList">
                    <li>
                        <div id="ctl00_ctl24_mstFooterMsLinkListTitle" class="mstFooterMsLinkListTitle">Other Microsoft sites</div>
                    </li>
                    
                            <li class="mstFooterMsLinkItemLi">
                                <div id="ctl00_ctl24_mstFooterMsLink_Repeater_ctl00_mstFooterMsLinkItem" class="mstFooterMsLinkItem">
                                    <a href="http://windows.microsoft.com/en-US/windows/home" id="ctl00_ctl24_mstFooterMsLink_Repeater_ctl00_mstFooterMsLinkItemLink" class="mstFooterMsLinkItemLink"><div title="Windows"><img alt="Windows" src="http://www.microsoft.com/global/onemscomsettings/publishingimages/footerimages/windowslogo.png" width="100%" height="100%" ></img></div></a>
                                    <div id="ctl00_ctl24_mstFooterMsLink_Repeater_ctl00_mstFooterMsLinkItemText" class="mstFooterMsLinkItemText"><a href="http://windows.microsoft.com/en-US/windows/home" ><span>Windows</span></a></div>
                                </div>
                            </li>
                        
                            <li class="mstFooterMsLinkItemLi">
                                <div id="ctl00_ctl24_mstFooterMsLink_Repeater_ctl01_mstFooterMsLinkItem" class="mstFooterMsLinkItem">
                                    <a href="http://office.microsoft.com/en-us/" id="ctl00_ctl24_mstFooterMsLink_Repeater_ctl01_mstFooterMsLinkItemLink" class="mstFooterMsLinkItemLink"><div title="Office"><img alt="Office" src="http://www.microsoft.com/global/onemscomsettings/publishingimages/footerimages/officelogo.png" width="100%" height="100%" ></img></div></a>
                                    <div id="ctl00_ctl24_mstFooterMsLink_Repeater_ctl01_mstFooterMsLinkItemText" class="mstFooterMsLinkItemText"><a href="http://office.microsoft.com/en-us/" ><span>Office</span></a></div>
                                </div>
                            </li>
                        
                            <li class="mstFooterMsLinkItemLi">
                                <div id="ctl00_ctl24_mstFooterMsLink_Repeater_ctl02_mstFooterMsLinkItem" class="mstFooterMsLinkItem">
                                    <a href="http://www.microsoft.com/windowsphone/en-us/default.aspx" id="ctl00_ctl24_mstFooterMsLink_Repeater_ctl02_mstFooterMsLinkItemLink" class="mstFooterMsLinkItemLink"><div title="Windows Phone"><img alt="Windows Phone" src="http://www.microsoft.com/global/onemscomsettings/publishingimages/footerimages/phonelogo.png" width="100%" height="100%" ></img></div></a>
                                    <div id="ctl00_ctl24_mstFooterMsLink_Repeater_ctl02_mstFooterMsLinkItemText" class="mstFooterMsLinkItemText"><a href="http://www.microsoft.com/windowsphone/en-us/default.aspx" ><span>Windows Phone</span></a></div>
                                </div>
                            </li>
                        
                            <li class="mstFooterMsLinkItemLi">
                                <div id="ctl00_ctl24_mstFooterMsLink_Repeater_ctl03_mstFooterMsLinkItem" class="mstFooterMsLinkItem">
                                    <a href="http://www.xbox.com/en-US/" id="ctl00_ctl24_mstFooterMsLink_Repeater_ctl03_mstFooterMsLinkItemLink" class="mstFooterMsLinkItemLink"><div title="Xbox"><img alt="Xbox" src="http://www.microsoft.com/global/onemscomsettings/publishingimages/footerimages/xboxlogo.png" width="100%" height="100%" ></img></div></a>
                                    <div id="ctl00_ctl24_mstFooterMsLink_Repeater_ctl03_mstFooterMsLinkItemText" class="mstFooterMsLinkItemText"><a href="http://www.xbox.com/en-US/" ><span>Xbox</span></a></div>
                                </div>
                            </li>
                        
                            <li class="mstFooterMsLinkItemLi">
                                <div id="ctl00_ctl24_mstFooterMsLink_Repeater_ctl04_mstFooterMsLinkItem" class="mstFooterMsLinkItem">
                                    <a href="http://www.skype.com/intl/en-us/home" id="ctl00_ctl24_mstFooterMsLink_Repeater_ctl04_mstFooterMsLinkItemLink" class="mstFooterMsLinkItemLink"><div title="Skype"><img alt="Skype" src="http://www.microsoft.com/global/onemscomsettings/publishingimages/footerimages/skypelogo.png" width="100%" height="100%" ></img></div></a>
                                    <div id="ctl00_ctl24_mstFooterMsLink_Repeater_ctl04_mstFooterMsLinkItemText" class="mstFooterMsLinkItemText"><a href="http://www.skype.com/intl/en-us/home" ><span>Skype</span></a></div>
                                </div>
                            </li>
                        
                            <li class="mstFooterMsLinkItemLi">
                                <div id="ctl00_ctl24_mstFooterMsLink_Repeater_ctl05_mstFooterMsLinkItem" class="mstFooterMsLinkItem">
                                    <a href="http://www.bing.com/" id="ctl00_ctl24_mstFooterMsLink_Repeater_ctl05_mstFooterMsLinkItemLink" class="mstFooterMsLinkItemLink"><div title="Bing"><img alt="Bing" src="http://www.microsoft.com/global/onemscomsettings/publishingimages/footerimages/binglogo.png" width="100%" height="100%" ></img></div></a>
                                    <div id="ctl00_ctl24_mstFooterMsLink_Repeater_ctl05_mstFooterMsLinkItemText" class="mstFooterMsLinkItemText"><a href="http://www.bing.com/" ><span>Bing</span></a></div>
                                </div>
                            </li>
                        
                            <li class="mstFooterMsLinkItemLi">
                                <div id="ctl00_ctl24_mstFooterMsLink_Repeater_ctl06_mstFooterMsLinkItem" class="mstFooterMsLinkItem">
                                    <a href="http://store.microsoft.com/" id="ctl00_ctl24_mstFooterMsLink_Repeater_ctl06_mstFooterMsLinkItemLink" class="mstFooterMsLinkItemLink"><div title="Microsoft Store"><img alt="Microsoft Store" src="http://www.microsoft.com/global/onemscomsettings/publishingimages/footerimages/storelogo.png" width="100%" height="100%" ></img></div></a>
                                    <div id="ctl00_ctl24_mstFooterMsLink_Repeater_ctl06_mstFooterMsLinkItemText" class="mstFooterMsLinkItemText"><a href="http://store.microsoft.com/" ><span>Microsoft Store</span></a></div>
                                </div>
                            </li>
                        
                </ul>
            </div>
            <div id="ctl00_ctl24_mstFooterDestLink" class="mstFooterDestLink" bi:type="oneMscomFooterDestLink">
                <div id="ctl00_ctl24_mstFooterDestLinkTemplate"><ul class="mstFooterDestLinkListOdd" ><li><ul class="mstFooterDestLinkCatList"><li class="mstFooterDestLinkListTitle"><div>Windows downloads</div></li><li class="mstFooterDestLinkListItem"><div><a  Href="http://www.microsoft.com/en-us/download/windows.aspx?q=windows" bi:cpid="dlcfatfooter"><span>All Windows products</span></a></div></li><li class="mstFooterDestLinkListItem"><div><a  Href="http://www.microsoft.com/en-us/download/windows-7.aspx?q=windows+7" bi:cpid="dlcfatfooter"><span>Windows 7</span></a></div></li><li class="mstFooterDestLinkListItem"><div><a  Href="http://www.microsoft.com/en-us/download/windows-xp.aspx?q=windows+xp" bi:cpid="dlcfatfooter"><span>Windows XP</span></a></div></li><li class="mstFooterDestLinkListItem"><div><a  Href="http://www.microsoft.com/en-us/download/ie.aspx?q=internet+explorer" bi:cpid="dlcfatfooter"><span>Internet Explorer</span></a></div></li></ul></li><li><ul class="mstFooterDestLinkCatList"><li class="mstFooterDestLinkListTitle"><div>Office downloads</div></li><li class="mstFooterDestLinkListItem"><div><a  Href="http://www.microsoft.com/en-us/download/office.aspx?q=office" bi:cpid="dlcfatfooter"><span>All Office products</span></a></div></li><li class="mstFooterDestLinkListItem"><div><a  Href="http://www.microsoft.com/en-us/download/office-2010.aspx?q=office+2010" bi:cpid="dlcfatfooter"><span>Office 2010</span></a></div></li><li class="mstFooterDestLinkListItem"><div><a  Href="http://www.microsoft.com/en-us/download/office-clip-art.aspx?q=office+templates" bi:cpid="dlcfatfooter"><span>Office clip art & templates</span></a></div></li></ul></li></ul><ul class="mstFooterDestLinkListEven" ><li><ul class="mstFooterDestLinkCatList"><li class="mstFooterDestLinkListTitle"><div>Security</div></li><li class="mstFooterDestLinkListItem"><div><a  Href="http://www.microsoft.com/en-us/download/security.aspx?q=security" bi:cpid="dlcfatfooter"><span>Security updates & tools</span></a></div></li><li class="mstFooterDestLinkListItem"><div><a  Href="http://www.microsoft.com/en-us/download/virus-malware.aspx?q=virus" bi:cpid="dlcfatfooter"><span>Virus & malware</span></a></div></li><li class="mstFooterDestLinkListItem"><div><a  Href="http://update.microsoft.com/" bi:cpid="dlcfatfooter"><span>Microsoft Update</span></a></div></li></ul></li><li><ul class="mstFooterDestLinkCatList"><li class="mstFooterDestLinkListTitle"><div>Download categories</div></li><li class="mstFooterDestLinkListItem"><div><a  Href="http://www.microsoft.com/en-us/download/search.aspx?p=0&r=10&t=&s=availabledate~Descending" bi:cpid="dlcfatfooter"><span>All downloads</span></a></div></li><li class="mstFooterDestLinkListItem"><div><a  Href="http://www.microsoft.com/en-us/download/driver.aspx?q=driver" bi:cpid="dlcfatfooter"><span>Drivers</span></a></div></li><li class="mstFooterDestLinkListItem"><div><a  Href="http://www.microsoft.com/en-us/download/servicepack.aspx?q=service+pack+downloads" bi:cpid="dlcfatfooter"><span>Service packs</span></a></div></li><li class="mstFooterDestLinkListItem"><div><a  Href="http://www.microsoft.com/en-us/download/security.aspx?q=security+downloads" bi:cpid="dlcfatfooter"><span>Security updates & tools</span></a></div></li></ul></li></ul></div>
            </div>
            <div id="ctl00_ctl24_mstFooterPopRes" class="mstFooterPopRes" bi:type="oneMscomFooterPopResLink">
                <ul class="mstFooterPopResList">
                    <li>
                        <div id="ctl00_ctl24_mstFooterPopResListTitle" class="mstFooterPopResListTitle">Popular resources</div>
                    </li>
                    
                            <li>
                                <div id="ctl00_ctl24_mstFooterPopRes_Repeater_ctl00_mstFooterPopResListItem" class="mstFooterPopResListItem"><a  Href="http://windows.microsoft.com/en-US/windows/products/security-essentials" bi:cpid="dlcfatfooter"><span>Free antivirus software</span></a></div>
                            </li>
                        
                            <li>
                                <div id="ctl00_ctl24_mstFooterPopRes_Repeater_ctl01_mstFooterPopResListItem" class="mstFooterPopResListItem"><a  Href="http://www.microsoft.com/security/pc-security/malware-removal.aspx" bi:cpid="dlcfatfooter"><span>Malware removal tool</span></a></div>
                            </li>
                        
                            <li>
                                <div id="ctl00_ctl24_mstFooterPopRes_Repeater_ctl02_mstFooterPopResListItem" class="mstFooterPopResListItem"><a  Href="http://www.microsoftstore.com/store/msstore/en_US/pd/productID.235488300/categoryID.5072610" bi:cpid="dlcfatfooter"><span>Windows 7 Home Premium</span></a></div>
                            </li>
                        
                            <li>
                                <div id="ctl00_ctl24_mstFooterPopRes_Repeater_ctl03_mstFooterPopResListItem" class="mstFooterPopResListItem"><a  Href="http://www.microsoftstore.com/store/msstore/en_US/pd/productID.229301900/categoryID.50726100" bi:cpid="dlcfatfooter"><span>Microsoft Office academic edition</span></a></div>
                            </li>
                        
                            <li>
                                <div id="ctl00_ctl24_mstFooterPopRes_Repeater_ctl04_mstFooterPopResListItem" class="mstFooterPopResListItem"><a  Href="http://www.microsoftstore.com/store/msstore/cat/categoryID.44066900" bi:cpid="dlcfatfooter"><span>Laptops and desktop computers</span></a></div>
                            </li>
                        
                            <li>
                                <div id="ctl00_ctl24_mstFooterPopRes_Repeater_ctl05_mstFooterPopResListItem" class="mstFooterPopResListItem"><a  Href="http://www.windowsphone.com/" bi:cpid="dlcfatfooter"><span>Windows Phone devices</span></a></div>
                            </li>
                        
                            <li>
                                <div id="ctl00_ctl24_mstFooterPopRes_Repeater_ctl06_mstFooterPopResListItem" class="mstFooterPopResListItem"><a  Href="http://www.windowsphone.com/en-US/marketplace" bi:cpid="dlcfatfooter"><span>Windows Phone apps and games</span></a></div>
                            </li>
                        
                            <li>
                                <div id="ctl00_ctl24_mstFooterPopRes_Repeater_ctl07_mstFooterPopResListItem" class="mstFooterPopResListItem"><a  Href="http://www.microsoftstore.com/store/msstore/en_US/pd/productID.216677300/categoryID.50726100" bi:cpid="dlcfatfooter"><span>Xbox 360 4GB with Kinect</span></a></div>
                            </li>
                        
                            <li>
                                <div id="ctl00_ctl24_mstFooterPopRes_Repeater_ctl08_mstFooterPopResListItem" class="mstFooterPopResListItem"><a  Href="http://www.microsoft.com/en-us/cloud/default.aspx" bi:cpid="dlcfatfooter"><span>Cloud computing solutions</span></a></div>
                            </li>
                        
                            <li>
                                <div id="ctl00_ctl24_mstFooterPopRes_Repeater_ctl09_mstFooterPopResListItem" class="mstFooterPopResListItem"><a  Href="http://www.microsoft.com/en-us/dynamics/default.aspx" bi:cpid="dlcfatfooter"><span>Microsoft Dynamics Online CRM</span></a></div>
                            </li>
                        
                </ul>
            </div>
        </div>    
        <div class="mstFooterBottom">
            <div id="ctl00_ctl24_mstFooterLocaleLogo" class="mstFooterLocaleLogo" bi:type="oneMscomFooterLocaleLogo">
                <div class="mstFooterLocale">
                    <div id="ctl00_ctl24_ctl00_oneMscomLocalePicker" class="oneMscomLocalePicker">
    <div id="ctl00_ctl24_ctl00_mstLcpMenu" class="mstLcpMenu"><a href="http://www.microsoft.com/en-us/download/details.aspx?id=35845&amp;mstLocPickShow=True" id="mstLocPickerCtl" bi:track="false" ><div class="mstLcpMenuImg" ><img src="http://www.microsoft.com/global/onemscomsettings/publishingimages/footerimages/footer_globe.png" /></div><span class="mstLcpMenuText">United States </span></a></div>
    
    <div id="ctl00_ctl24_ctl00_mstLcpFlyout" class="mstLcpFlyout">
        

        <div>
            <!--site in other languages-->
            <div class="mstLcpLangSites">
                
                        <div class="mstLcpClose2">
                            <a href="http://www.microsoft.com/en-us/download/details.aspx?id=35845&amp;mstLocPickShow=False" bi:track="false">
                                <img src="http://www.microsoft.com/global/onemscomsettings/publishingimages/commonimages/flyoutclosebtnround.png"/>
                            </a>
                        </div>
                
                <div class="cssClear"></div>
            </div>
            <!--all sites text-->
            <div class="mstLcpAllSites">
                <div class="mstLcpAllSitesText">
                    <!--set text based on locale present, if none then set site not available in other languages-->
                    This site in other countries/regions: 
	                        
                </div>
                <div id="ctl00_ctl24_ctl00_mstLcpSearch" class="mstLcpSearch">

                

                        <span class="mstLcpSearchContainter">
                            <span class="mstLcpSearchBorder">
                                <input name="ctl00$ctl24$ctl00$mstLcpSearchText" type="text" id="ctl00_ctl24_ctl00_mstLcpSearchText" class="mstLcpSearchText" title="Search for a language or locale" />
                                <span class="mstLcpSearchImg"></span>
                            </span>
                        </span>

                    </div>
            </div>
            <div class="mstLcpAllSitesLinks">
            
                
                    <ul class="mstLcpAllSitesList mstLcpListNotLast">
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=tn-za" >
                                    <span dir="ltr">
                                        Aforika Borwa - Setswana(South Africa)
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/en-au/download/default.aspx" >
                                    <span dir="ltr">
                                        Australia - English
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/nl-be/download/default.aspx" >
                                    <span dir="ltr">
                                        België - Nederlands
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/fr-be/download/default.aspx" >
                                    <span dir="ltr">
                                        Belgique - Français
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/bs-ba/download/default.aspx" >
                                    <span dir="ltr">
                                        Bosnia and Herzegovina
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=tn" >
                                    <span dir="ltr">
                                        Botswana - Setswana
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/pt-br/download/default.aspx" >
                                    <span dir="ltr">
                                        Brazil - Portuguese
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=ms-bn" >
                                    <span dir="ltr">
                                        Brunei Darussalam - Malay
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/en-ca/download/default.aspx" >
                                    <span dir="ltr">
                                        Canada - English
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/fr-ca/download/default.aspx" >
                                    <span dir="ltr">
                                        Canada - Français
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/cs-cz/download/default.aspx" >
                                    <span dir="ltr">
                                        Česká Republika - Čeština
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/da-dk/download/default.aspx" >
                                    <span dir="ltr">
                                        Denmark - Danish
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/de-de/download/default.aspx" >
                                    <span dir="ltr">
                                        Deutschland - Deutsch
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=et" >
                                    <span dir="ltr">
                                        Estonia - Estonian
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/en-eg/download/default.aspx" >
                                    <span dir="ltr">
                                        Egypt - English
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/fr-fr/download/default.aspx" >
                                    <span dir="ltr">
                                        France - Français
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=eu" >
                                    <span dir="ltr">
                                        Frantzia - Euskara
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/es-es/download/default.aspx" >
                                    <span dir="ltr">
                                        España - Español
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=gl" >
                                    <span dir="ltr">
                                        Galicia - Galician
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=ca" >
                                    <span dir="ltr">
                                        Espanya  - Català
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/en-hk/download/default.aspx" >
                                    <span dir="ltr">
                                        Hong Kong SAR - English
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/hr-hr/default.aspx" >
                                    <span dir="ltr">
                                        Hrvatska - Hrvatski
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/en-in/download/default.aspx" >
                                    <span dir="ltr">
                                        India - English
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=id" >
                                    <span dir="ltr">
                                        Indonesia - Bahasa Indonesia
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=zu" >
                                    <span dir="ltr">
                                        iNingizimu Afrika - isiZulu
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/en-ie/download/default.aspx" >
                                    <span dir="ltr">
                                        Ireland - English
                                    </span>
                                </a>
                            </li>
                                            
                    
                    </ul>
                
                    <ul class="mstLcpAllSitesList mstLcpListNotLast">
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=ga" >
                                    <span dir="ltr">
                                        Éire - Ireland
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/is-is/download/default.aspx" >
                                    <span dir="ltr">
                                        Ísland - Íslenska
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/it-it/download/default.aspx" >
                                    <span dir="ltr">
                                        Italia - Italiano
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/lv-lv/download/default.aspx" >
                                    <span dir="ltr">
                                        Latvija - Latviešu
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/lt-lt/download/default.aspx" >
                                    <span dir="ltr">
                                        Lietuva - Lietuvių
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/hu-hu/download/default.aspx" >
                                    <span dir="ltr">
                                        Magyarország - magyar
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=ms" >
                                    <span dir="ltr">
                                        Malaysia - Malay
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=mt" >
                                    <span dir="ltr">
                                        Malta - Maltese
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/es-mx/download/default.aspx" >
                                    <span dir="ltr">
                                        México - Español
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/nl-nl/download/default.aspx" >
                                    <span dir="ltr">
                                        Nederland - Nederlands
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/en-nz/download/default.aspx" >
                                    <span dir="ltr">
                                        New Zealand - English
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=mi" >
                                    <span dir="ltr">
                                        New Zealand - Māori
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=ig" >
                                    <span dir="ltr">
                                        Nigeria - Igbo
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=yo" >
                                    <span dir="ltr">
                                        Nigeria - Yoruba
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/nb-no/download/default.aspx" >
                                    <span dir="ltr">
                                        Norge -Bokmål
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/de-at/download/default.aspx" >
                                    <span dir="ltr">
                                        Österreich - Deutsch
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=qu" >
                                    <span dir="ltr">
                                        Peru - Quechua
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/pl-pl/download/default.aspx" >
                                    <span dir="ltr">
                                        Polska - Polski
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/pt-pt/download/default.aspx" >
                                    <span dir="ltr">
                                        Portugal - Português
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/ro-ro/download/default.aspx" >
                                    <span dir="ltr">
                                        România - Română
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=rw" >
                                    <span dir="ltr">
                                        Rwanda - Kinyarwanda
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/en-sa/download/default.aspx" >
                                    <span dir="ltr">
                                        Saudi Arabia - English
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/de-ch/download/default.aspx" >
                                    <span dir="ltr">
                                        Schweiz - Deutsch
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=wo" >
                                    <span dir="ltr">
                                        Senegal - Wolof
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=sq" >
                                    <span dir="ltr">
                                        Shqipëria - Albanian
                                    </span>
                                </a>
                            </li>
                                            
                    
                    </ul>
                
                    <ul class="mstLcpAllSitesList mstLcpListNotLast">
                        
                            <li>
                                <a href="http://www.microsoft.com/en-sg/download/default.aspx" >
                                    <span dir="ltr">
                                        Singapore - English
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/sl-si/download/default.aspx" >
                                    <span dir="ltr">
                                        Slovenija - Slovenščina
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/sk-sk/download/default.aspx" >
                                    <span dir="ltr">
                                        Slovenská Republika – slovenčina
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/en-za/download/default.aspx" >
                                    <span dir="ltr">
                                        South Africa - English
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=af" >
                                    <span dir="ltr">
                                        Suid-Afrika - Afrikaans
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/fr-ch/download/default.aspx" >
                                    <span dir="ltr">
                                        Suisse - Français
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/fi-fi/download/default.aspx" >
                                    <span dir="ltr">
                                        Suomi - Finnish
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/sv-se/download/default.aspx" >
                                    <span dir="ltr">
                                        Sverige - Svenska
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=rm" >
                                    <span dir="ltr">
                                        Switzerland - Romansh
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/tr-tr/download/default.aspx" >
                                    <span dir="ltr">
                                        Türkiye - Türkçe
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=xh" >
                                    <span dir="ltr">
                                        uMzantsi Afrika - isiXhosa
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/en-gb/download/default.aspx" >
                                    <span dir="ltr">
                                        United Kingdom - English
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/vi-vn/download/default.aspx" >
                                    <span dir="ltr">
                                        Việt Nam- Vietnamese
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/el-gr/download/default.aspx" >
                                    <span dir="ltr">
                                        Ελλάδα - Ελληνικά
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=be" >
                                    <span dir="ltr">
                                        Беларусь - Беларуская
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/bg-bg/download/default.aspx" >
                                    <span dir="ltr">
                                        България - Български
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=ky" >
                                    <span dir="ltr">
                                        Кыргызстан - Kyrgyz
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=kk" >
                                    <span dir="ltr">
                                        Қазақстан - Kazakh
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=mk" >
                                    <span dir="ltr">
                                        Македонија, ПЈРМ – Македонски
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/ru-ru/download/default.aspx" >
                                    <span dir="ltr">
                                        Россия - Русский
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=tt" >
                                    <span dir="ltr">
                                        Россия - Tatar
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/uk-ua/download/default.aspx" >
                                    <span dir="ltr">
                                        Україна - Українська
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=hy" >
                                    <span dir="ltr">
                                        Հայաստան - Հայերեն
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=ka" >
                                    <span dir="ltr">
                                        საქართველო - Georgian
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=he" >
                                    <span dir="ltr">
                                        ישראל - עברית
                                    </span>
                                </a>
                            </li>
                                            
                    
                    </ul>
                
                    <ul class="mstLcpAllSitesList">
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=ar" >
                                    <span dir="ltr">
                                        ليبيا - العربية
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=fa" >
                                    <span dir="ltr">
                                        ایران
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=mr" >
                                    <span dir="ltr">
                                        भारत - मराठी
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/hi-in/download/default.aspx" >
                                    <span dir="ltr">
                                        भारतम् - हिंदी
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=bn-bd" >
                                    <span dir="ltr">
                                        বাংলাদেশ -  বাংলা
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=as" >
                                    <span dir="ltr">
                                        ভাৰত - অসমীয়া
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=bn" >
                                    <span dir="ltr">
                                        ভারত - বাংলা
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=gu" >
                                    <span dir="ltr">
                                        ભારત - ગુજરાતી
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=kn" >
                                    <span dir="ltr">
                                        ഭാരതം - ಕನ್ನಡ
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=kok" >
                                    <span dir="ltr">
                                        ಭಾರತ -ಕನ್ನಡ
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=or" >
                                    <span dir="ltr">
                                        ଭାରତ - ଓଡ଼ିଆ
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=ta" >
                                    <span dir="ltr">
                                        இந்தியா - தமிழ்
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=te" >
                                    <span dir="ltr">
                                        భారత దేశం - తెలుగు
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=ml" >
                                    <span dir="ltr">
                                        ഭാരതം - മലയാളം
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=urpk" >
                                    <span dir="ltr">
                                        اُردو - پاکستان 
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=si" >
                                    <span dir="ltr">
                                        ශ්‍රී ලංකා
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/th-th/download/default.aspx" >
                                    <span dir="ltr">
                                        ไทย - ไทย
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=lo" >
                                    <span dir="ltr">
                                        ລາວ -  ສ.ປ.ປ. ລາວ
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=km" >
                                    <span dir="ltr">
                                        ខ្មែរ - កម្ពុជា
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/downloads/search.aspx?displaylang=am" >
                                    <span dir="ltr">
                                        አማርኛ -  ኢትዮጵያ
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/ko-kr/download/default.aspx" >
                                    <span dir="ltr">
                                        대한민국 - 한국어
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/zh-cn/download/default.aspx" >
                                    <span dir="ltr">
                                        中国 - 简体中文
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/zh-tw/download/default.aspx" >
                                    <span dir="ltr">
                                        台灣 - 繁體中文
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/ja-jp/download/default.aspx" >
                                    <span dir="ltr">
                                        日本 - 日本語
                                    </span>
                                </a>
                            </li>
                        
                            <li>
                                <a href="http://www.microsoft.com/zh-hk/download/default.aspx" >
                                    <span dir="ltr">
                                        香港特別行政區 - 中文
                                    </span>
                                </a>
                            </li>
                                            
                    
                    </ul>
                
                <div class="cssClear"></div>            
            </div>

        </div>        

    </div>
</div>
                </div>
                <div id="ctl00_ctl24_mstFooterLogo" class="mstFooterLogo"><a href="http://www.microsoft.com/en/us/default.aspx"  ><span><img alt="Microsoft" src="http://www.microsoft.com/global/onemscomsettings/publishingimages/microsoft_logo_footer_v3.png" /></span></a></div>
            </div>
            <div class="mstFooterCorpLinkCopyright">
                <div id="ctl00_ctl24_mstFooterCopyRight" class="mstFooterCopyRight"><div>&copy;2012 Copyright</div></div>
                <div id="ctl00_ctl24_mstFooterCorpLink" class="mstFooterCorpLink" bi:type="oneMscomFooterCorpLink"><ul><li class="msFooterCorpLinkLi"></li><li class="msFooterCorpLinkLi"><a href="http://support.microsoft.com/contactus/?ws=mscom"  ><span>Contact Us</span></a></li><li class="msFooterCorpLinkLi"><a href="http://www.microsoft.com/About/Legal/EN/US/IntellectualProperty/Copyright/default.aspx"  ><span>Terms of Use</span></a></li><li class="msFooterCorpLinkLi"><a href="http://www.microsoft.com/About/Legal/EN/US/IntellectualProperty/Trademarks/EN-US.aspx"  ><span>Trademarks</span></a></li><li class="msFooterCorpLinkLi"><a href="http://go.microsoft.com/fwlink/?LinkId=248681"  ><span>Privacy & Cookies</span></a></li></ul></div>
                <div id="ctl00_ctl24_mstFooterMoreCorpLink" class="mstFooterMoreCorpLink" bi:type="oneMscomFooterCorpLink"><ul><li class="msFooterCorpLinkLi"></li></ul></div>
            </div>            
        </div>
    </div>
    

    <script type="text/javascript">

        if (typeof $ != "undefined") {
            $(function () {
                if (Mst && Mst.FooterV3) {
                    var footerV3 = new Mst.FooterV3('ctl00_ctl24', '916', '');
                }
            });
        }

    
    </script>

       
 
                        
                    </div>
                    
                </div>
                <div class="cssClear"></div>
            </div>
        </div>
        <div class="hpMst_StageBottom">
            
        </div>
    
<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['aspnetForm'];
if (!theForm) {
    theForm = document.aspnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>

</form>
    
<script type="text/javascript">
var varSegmentation=1;
var varClickTracking=0;
var varCustomerTracking=1;
var varLoadTracking=0;
</script>
<noscript><img alt="" width="1" height="1" src="http://c.microsoft.com/trans_pixel.aspx"/></noscript>
    <script type="text/javascript" src="http://i.microsoft.com/en-us/download/script.jsx?k=~/shared/templates/components/mscomViews/Controls/Scripts/jquery.bi.js;~/shared/templates/components/mscomViews/Controls/Scripts/jquery.bi.dataretrievers.attr.js;~/shared/templates/components/mscomViews/Controls/Scripts/jquery.bi.dataretrievers.structure.js;~/shared/templates/components/mscomViews/Controls/Scripts/jquery.bi.queue.js;~/shared/templates/components/mscomViews/controls/scripts/wedcs.js;~/shared/templates/components/mscomViews/Controls/Scripts/jquery.bi.dataconsumers.wedcs.js;~/shared/templates/components/mscomViews/Controls/Scripts/webtrends_16.js;~/shared/templates/components/mscomViews/Controls/Scripts/jquery.bi.dataconsumers.webtrends.js;~/shared/templates/components/omniDetails/DownloadUsage.js&amp;v=1638715203"></script>
    
    <script src="http://i.microsoft.com/en-us/download/bimapping.js?gv=BiMapping&amp;k=/en-us/download/Components/BiMapping.xml&amp;v=1216712542" type="text/javascript"></script>
    <script type="text/javascript">window.requestId='e24bd5ba-dc4a-4336-9ed3-b1f1a6d2766a';</script>
    <script type="text/javascript">
        if (typeof $ != "undefined" && typeof $.bi != "undefined") {
            $.bi.init(window.BiMapping);
            if (typeof window.requestId != "undefined") {
                $.bi.baseData({ requestId: window.requestId });
            }
            
            if (typeof $.bi.dataConsumers != undefined && $.bi.dataConsumers.webtrends != "undefined" && typeof $.bi.dataConsumers.webtrends.WebTrends != "undefined") {
                $.bi.dataConsumers.webtrends.WebTrends.dcsid = "dcs1tn7q7wz5bdpbasr9xsxin_9s8i";
                $.bi.dataConsumers.webtrends.WebTrends.dcsGetId();
            }
            
        }
        if (typeof QosRecord != "undefined") {
            $(function () { QosRecord('domready'); });
        }

        if (typeof $ != "undefined" && typeof WTOptimize != "undefined") {
            (function () {
                var optimizeDone = function () {
                    $(function () {
                        try { window.Hp.Grid.ignoreWrapper('SaaS_MVT'); } catch (e) { }
                        window.setTimeout(function () { $('.hpPvt_body:visible,.hpVpv_Body:visible').trigger('PivotShow'); }, 500);
                    });
                };
                WTOptimize.addEventHandler(WTEvent.DONE, optimizeDone, optimizeDone);
            })();
        }
    </script>

</body>
</html>
